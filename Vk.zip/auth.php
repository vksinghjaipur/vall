//import auth

use Auth;
or
use Illuminate\Support\Facades\Auth;




$userDetails = Auth::user(); 		//all user details
$id = Auth::user()->id; 			//only user details

