@extends('layouts.app') 
@section('content')

<div class="container-fluid">
    <div class="row"> 
      <div class="col-12">

      @if ($message = Session::get('success'))  
      <div class="alert alert-success alert-block">  
          <button type="button" class="close" data-dismiss="alert">?</button>   
              <strong>{{ $message }}</strong>  
      </div>  
      @endif    


        <div class="page-title-box">
          <div class="page-title-right" style="display: block"> 
            <a href="{{route("$viewPath.create")}}" class="btn btn-dark btn-rounded"><span class="uil uil-plus"></span> Add Client</a> 
          </div>
          <h4 class="page-title">Clients List</h4>
        </div>
      </div>
      <div class="col-xl-12 col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="" class="table table-bordered table-centered mb-0">   
              <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Email</th>
                  <th>Mobile</th>
                  <th class="text-center">Sites</th>
                  <th class="text-center">Action</th>
                </tr>
              </thead>

              @foreach($result as $allusers)  
              <tbody>
                <tr>
                  <td><a href="{{route("$viewPath.show",$allusers->id)}}">{{$allusers->full_name}}</a></td>
                  <td>{{$allusers->email}}</td>
                  <td>{{$allusers->mobile}}</td>
                  <td class="text-center">{{$allusers->industry_id}}</td>  
                  <td class="table-action text-center">
                    <div class="col-auto">
                    @if($allusers->is_favourite==0)  
                      <a href="{{route("$viewPath.favourite",$allusers->id)}}" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-muted btn-lg p-0" data-original-title="Favourite"> <i class="mdi mdi-heart-outline"></i> </a>
                    @else
                      <a href="{{route("$viewPath.favourite",$allusers->id)}}" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-muted btn-lg p-0" data-original-title="Favourite"> <i class="mdi mdi-heart" style='color: red'></i> </a>
                    @endif

                    <a href="{{route("$viewPath.destroy",$allusers->id)}}" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-danger btn-lg p-0 pr-2 ml-2" data-original-title="Delete"> <i class="uil uil-multiply"></i></a> 
                    <a href="{{route("$viewPath.edit",$allusers->id)}}" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-muted btn-lg p-0 pr-2" data-original-title="Edit"> <i class="uil uil-edit-alt"></i></a></div>
                  
                  </td>
                  
                </tr>
              </tbody>
              @endforeach
              </table>
              <div class='card-body'>
               {{ $result->links('pagination.app')}}
               {{-- {{ $result->links('vendor.pagination.custom')}} --}}
              </div>
              </div>
             
            </div>
            
          </div>
        </div>
      </div>
    </div>
</div>

@endsection