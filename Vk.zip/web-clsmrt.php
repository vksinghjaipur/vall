<?php


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TicketsController;
use App\Http\Controllers\CleaningcompaniesController;
use App\Http\Controllers\MyTestController;

use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;


/*

|--------------------------------------------------------------------------

| Web Routes

|--------------------------------------------------------------------------

|

| Here is where you can register web routes for your application. These

| routes are loaded by the RouteServiceProvider within a group which

| contains the "web" middleware group. Now create something great!

|

*/



Auth::routes();


/* overwrite default auth guard as web */
config(['auth.defaults.guard' => 'web']);

Route::get('/', function () {

    return view('welcome');

});

/********************Forget Password Start ******************/

Route::get('/forgot-password', function () {
    return view('auth.forgot-password');
})->name('password.request');

Route::post('/forgot-password', function (Request $request) {
    $request->validate(['email' => 'required|email']);
 
    $status = Password::sendResetLink(
        $request->only('email')
    );
 
    return $status === Password::RESET_LINK_SENT
                ? back()->with(['status' => __($status)])
                : back()->withErrors(['email' => __($status)]);
})->middleware('guest')->name('password.email');

Route::get('/reset-password/{token}', function ($token) {
    return view('auth.reset-password', ['token' => $token]);
})->middleware('guest')->name('password.reset');



Route::post('/reset-password', function (Request $request) {
    $request->validate([
        'token' => 'required',
        'email' => 'required|email',
        'password' => 'required|min:6|confirmed',
    ]);
 
    $status = Password::reset(
        $request->only('email', 'password', 'password_confirmation', 'token'),
        function ($user, $password) {
            $user->forceFill([
                'password' => Hash::make($password)
            ])->setRememberToken(Str::random(60));
 
            $user->save();
 
            event(new PasswordReset($user));
        }
    );
 
    return $status === Password::PASSWORD_RESET
                ? redirect()->route('login')->with('status', __($status))
                : back()->withErrors(['email' => [__($status)]]);
})->middleware('guest')->name('password.update');

/*****************Forget Password End ***********************/


Route::middleware(['auth'])->namespace('App\Http\Controllers')->group(function () {

    Route::get('/', 'DashboardController@index');

    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

    Route::get('profile/{id}','DashboardController@profile')->name('users.profile');
    Route::post('update-profile/{id}','DashboardController@updateProfile')->name('update.profile');

    Route::get('/change-password','DashboardController@changepassword')->name('users.change-password');
    Route::post('/change-password','DashboardController@updatepassword')->name('users.update-password');

    Route::get('/logout', 'DashboardController@logout')->name('logout');

    Route::get('scope/get-area', 'ScopeController@getAreaList')->name('scope.getAreaList');
    Route::post('scope/get-cleaning-option', 'ScopeController@getcleaningOptionList')->name('scope.getcleaningOptionList');
    Route::post('scope/get-cleaning-option-items', 'ScopeController@getcleaningOptionItemList')->name('scope.getcleaningOptionItemList');
    Route::post('scope/create-added-option', 'ScopeController@createAddedOptions')->name('scope.createAddedOptions');
    Route::post('scope/remove-added-option', 'ScopeController@removeAddedOptions')->name('scope.removeAddedOptions');
    Route::post('scope/create-selected-option', 'ScopeController@createSelectedOptions')->name('scope.createSelectedOptions');
    Route::resource('scope', 'ScopeController');
    
    Route::name('audit.')->group(function () {
        Route::get("/audit", "AuditController@index")->name('index');
        
        Route::get("/audit/site/{SITE_ID}", "AuditController@siteAreaAudit")->name('siteAreaAudit');
        Route::get("/audit/site/{SITE_ID}/{AREA_ID}", "AuditController@siteAreaItemsAudit")->name('siteAreaItemsAudit');
        
        Route::get("/audit/list/{SITE_ID}/create", "AuditController@siteArea")->name('siteArea');
        Route::get("/audit/list/{SITE_ID}/{AREA_ID}/create", "AuditController@siteAreaItems")->name('siteAreaItems');
        
        Route::post("/audit/save/{SITE_ID}/{AREA_ID}", "AuditController@saveAudit")->name('saveAudit');

        Route::get("/audit/add", "AuditController@create")->name('create');
        Route::get("/audit/edit/{id}", "AuditController@edit")->name('edit');
        Route::PUT("/audit/edit/{id}", "AuditController@update")->name('update');
        Route::get("/audit/delete/{id}", "AuditController@destroy")->name('destroy');
        Route::get("/audit/{id}", "AuditController@show")->name('show');
        
    });
    

    
    Route::get('client/favourite/{id}','ClientController@favourite')->name('client.favourite');
    Route::get('client/list','ClientController@getClientList')->name('client.getClientList');
    Route::post('client/update-favourite','ClientController@updateFavourite')->name('client.updateFavourite');
    Route::any('client-details/{id}','ClientController@details')->name('client.details');
    Route::resource('client', 'ClientController');
    Route::resource('subadmin', 'SubadminController');
    Route::name('users.')->group(function () {
        Route::get("/users", "SubadminController@index")->name('index');
        Route::get("/users/add", "SubadminController@create")->name('create');
        Route::post("/users/add", "SubadminController@store")->name('store');
        Route::get("/users/edit/{id}", "SubadminController@edit")->name('edit');
        Route::PUT("/users/edit/{id}", "SubadminController@update")->name('update');
        Route::get("/users/delete/{id}", "SubadminController@destroy")->name('destroy');
        Route::get("/users/{id}", "SubadminController@show")->name('show');
        Route::get("import", "SubadminController@import")->name('import');
        Route::post("import", "SubadminController@importCleaner")->name('import');
        
    });
    
    //Route::resource('chat', 'ChatController');
    Route::resource('test', 'MyTestController');

    /***********Sites Routes *********/

    Route::name('sites.')->group(function () {
        Route::get("/sites", "SitesController@index")->name('index');
        Route::get("/sites/add", "SitesController@create")->name('create');
        Route::post("/sites/add", "SitesController@store");
        Route::get("/sites/edit/{id}", "SitesController@edit")->name('edit');
        Route::PUT("/sites/edit/{id}", "SitesController@update");
        Route::get("/sites/delete/{id}", "SitesController@destroy")->name('destroy');
        Route::get("/sites-details/{id}", "SitesController@sites_details")->name('sites-details');
        Route::any('/sites/list','SitesController@getSiteList')->name('getSiteList');
    });
    
    
    /***********Cleaning Companies *********/
    Route::get("/cleaning-companies", [CleaningcompaniesController::class, "index"])->name('cleaning-companies');
    Route::get("/cleaning-companies/add", [CleaningcompaniesController::class, "create"])->name('cleaning-companies.add');
    Route::post("/cleaning-companies/add", [CleaningcompaniesController::class, "store"]);
    Route::get("/cleaning-companies/edit/{id}", [CleaningcompaniesController::class, "edit"])->name('cleaning-companies.edit');
    Route::PUT("/cleaning-companies/edit/{id}", [CleaningcompaniesController::class, "update"]);
    Route::get("/cleaning-companies/remove/{id}", [CleaningcompaniesController::class, "remove"])->name('cleaning-companies.remove');
    Route::get("/cleaning-companies/delete/{id}", [CleaningcompaniesController::class, "destroy"])->name('cleaning-companies.destroy');
    Route::get("/cleaning-companies-details/{id}", [CleaningcompaniesController::class, "show"])->name('cleaning-companies.details');
    Route::post("/cleaning-companies/get-details", [CleaningcompaniesController::class, "getCleaningCompanyData"])->name('cleaning-companies.getCleaningCompanyData');
    Route::post("/cleaning-companies/mark-favourite", [CleaningcompaniesController::class, "updateFavourite"])->name('cleaning-companies.updateFavourite');
    Route::post("/cleaning-companies/check-abn", [CleaningcompaniesController::class, "checkAbnNumber"])->name('cleaning-companies.check-abn');
    Route::post("/cleaning-companies/document-verified", [CleaningcompaniesController::class, "verifyCompayDocument"])->name('cleaning-companies.document-verified');
    Route::post("/cleaning-companies/verify-document", [CleaningcompaniesController::class, "verifyCompanyDocuments"])->name('cleaning-companies.verify-document');
    /***********End Cleaning Companies *********/

    /***********Sites Mnager Tickets *********/
    Route::get("/tickets", [TicketsController::class, "index"])->name('tickets');
    Route::get("/tickets/site/{SITE_ID}", [TicketsController::class, "index"])->name('tickets.site');
    Route::get("/tickets/add", [TicketsController::class, "create"])->name('tickets.add');
    Route::post("/tickets/add", [TicketsController::class, "store"]);
    Route::get("/tickets/edit/{id}", [TicketsController::class, "edit"])->name('tickets.edit');
    Route::PUT("/tickets/edit/{id}", [TicketsController::class, "update"]);
    Route::get("/tickets/delete/{id}", [TicketsController::class, "destroy"])->name('tickets.destroy');
    Route::get("/tickets-details/{id}", [TicketsController::class, "show"])->name('tickets.details');
    Route::post("/tickets/update-status", [TicketsController::class, "updateStatus"])->name('tickets.updateStatus');
    Route::post("/tickets/update-type", [TicketsController::class, "updateType"])->name('tickets.updateType');
    /***********End Sites Mnager Tickets *********/
    
    
    /***********Common Routes *********/
    Route::get("/show-details/{id}", "Controller@details")->name('show-details');
    /***********End Common Routes *********/
    
    Route::name('chat.')->group(function () {
        Route::get('/chat', 'ChatController@index')->name('index');;
        Route::get('/chat/{userId}', 'ChatController@startChat')->name('start');
        Route::get('/chat/{userId}/conversations/{type}', 'ChatController@conversations')->name('conversations');
        Route::post('/chat/{userId}/create-group', 'ChatController@createGroup')->name('createGroup');

    });
    Route::name('chatGroup.')->group(function () {
        Route::get('/group/create', 'ChatGroupController@create_form');
        Route::post('/group/create', 'ChatGroupController@create');
        Route::get('/group/join', 'ChatGroupController@join_form');
        Route::post('/group/join', 'ChatGroupController@join');
        Route::get('/group/{id}', 'ChatGroupController@show_group');
        Route::get('/group/edit/{id}', 'ChatGroupController@edit');
        Route::post('/group/update/{id}', 'ChatGroupController@update');
        Route::delete('/group/delete/{id}', 'ChatGroupController@delete');
        Route::get('/group/members_list/{id}', 'ChatGroupController@members_list');
        Route::get('/remove_user/{id}/{user_id}', 'ChatGroupController@remove_user');
    });

     /*********************Calendar Event Routes********************/
    Route::get('/reminder', 'ReminderEventController@index')->name('reminder');
    Route::post('/reminder/add', 'ReminderEventController@addReminder')->name('reminder.add');
    Route::get('/reminder/getuserevents', 'ReminderEventController@getuserevents')->name('reminder.getuserevents');
    Route::post('/reminder/dragupdate', 'ReminderEventController@dargUpdateReminder')->name('reminder.dragupdate');
    Route::post('/reminder/eventdelete', 'ReminderEventController@deleteEventReminder')->name('reminder.eventdelete');
    Route::get('/reminder/userreminders', 'ReminderEventController@getUserReminderList')->name('reminder.userreminders');
    Route::post('/reminder/markasdone', 'ReminderEventController@markAsDone')->name('reminder.markasdone');
    /*********************Ene Calendar Events**********************/

    /************* Settings Controller Start *************/
    Route::get('/settings', 'SettingController@index')->name('settings.index');
    Route::post('/settings', 'SettingController@update')->name('settings.update');
    /************* Settings Controller End **************/

     /************* Industies, Cleaning Areas Controller Start *****************/   
    Route::get('/industries/list','IndustriesController@getIndustryList')->name('industries.getIndustryList');
    Route::resource('industries', 'IndustriesController');
    
    Route::get('/cleaningareas/list','CleaningareasController@getCleaningAreaList')->name('cleaningareas.getCleaningareaList');
    Route::resource('cleaningareas', 'CleaningareasController');

    /************* industries, Cleaning Areas Controller End ******************/

        
    
    Route::get('/vikash', function () {
        Artisan::call('storage:link');
    });

    Route::get('/clear-cache', function() {
        Artisan::call('cache:clear');
        return 'Application cache has been cleared';
    });

    Route::get('/config-cache', function() {
        Artisan::call('config:cache');
        return 'Application cache has been cleared';
    });



     /* Home Vikash Excel Export-Import Data*/
    Route::get('importExportView', [MyController::class, 'importExportView'])->name('importExportView');
    Route::get('export', [MyController::class, 'export'])->name('export');
    Route::post('import', [MyController::class, 'import'])->name('import');
    
      /* Home Vikash Full Calender*/
    Route::get('fullCalenderView', [FullcalenderController::class, 'fullCalender'])->name('fullCalenderView');
    // Route::post('addEvent', [FullcalenderController::class, 'storeEvent']);
    Route::post('calendar', [FullcalenderController::class, 'store'])->name('calendar.store');
    Route::patch('calendar/update/{id}', [FullcalenderController::class, 'update'])->name('calendar.update');
    Route::delete('calendar/destroy/{id}', [FullcalenderController::class, 'destroy'])->name('calendar.destroy');

   
     /* Home Vikash Event Calender*/
    Route::get('fullcalender', 'EventController@index')->name('fullcalender');
    Route::post('fullcalenderAjax','EventController@calendarEvents');
    
});

Route::get("/sadmin/reset-db/{PASS}", [MyTestController::class, "resetDb"]);