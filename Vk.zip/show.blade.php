@extends('layouts.app') 
@section('content')

<div class="container-fluid">
    <div class="row mt-3">
        <div class="col-sm-12">
            <div class="card bg-primary">
                <div class="card-body profile-user-box">
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="media">
                                @if(!empty($result->avtar))
                                <span class="float-left m-2 mr-4"><img src="{{ STORAGE_URL.$result->avtar}}" style="height: 100px;" alt="" class="rounded-circle img-thumbnail"></span>
                                @else
                                <span class="float-left m-2 mr-4"><img src="{{NO_USER_IMAGE}}" style="height: 100px;" alt="" class="rounded-circle img-thumbnail"></span>
                                @endif
                                <div class="media-body">
                                    <h4 class="mt-1 mb-1 text-white">{{isset($result->first_name)?$result->first_name:''}}</h4>
                                    <p class="font-13 text-white-50">Client</p>
                                
                                        <div class="row mb-0 text-light">
                                        <!--
                                            <div class="col-md-6">
                                                <h5 class="mb-1">0621 4587 6542</h5>
                                                <p class="mb-1 font-13 text-white-50">Contact Number</p>
                                            </div>
                                            <div class="col-md-6 ">
                                                <h5 class="mb-1">michael@cleansmart.com.au</h5>
                                                <p class="mb-1 font-13 text-white-50">Email Address</p>
                                            </div>
                                                -->
                                                <!-- <div class="col-md-6">
                                                <h5 class="mb-1">Moderate</h5>
                                                <p class="mb-1 font-13 text-white-50">Admin Panel Access</p>
                                                </div> -->

                                        <div class="col-md-6">
                                        @if($result->status==1)    
                                        <h5 class="mb-1">Active</h5>
                                        @else
                                        <h5 class="mb-1 text-danger">Inctive</h5>
                                        @endif
                                        <p class="mb-1 font-13 text-white-50">User Status</p>
                                    </div>
                                        
                                    </div>
                                </div> 
                            </div>
                        </div> 
                        <div class="col-sm-4">
                            <div class="mt-2 text-sm-right">
                                <a href="{{route('client.edit',$result->id)}}" class="btn btn-light">
                                    <i class="mdi mdi-account-edit mr-1"></i> Edit User
                                </a>
                            </div>
                            
                            <div class="mt-3 text-sm-right">
                                <a href="#/" class="btn btn-success">
                                    <i class="mdi mdi-chat mr-1"></i> Message
                                </a>
                            </div>
                        </div> 
                    </div> 
                </div> 
            </div>
        </div> 
    </div>
        
        <div class="row">
        <div class="col-lg-12">
            
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mt-0 mb-3">User Information</h4>
                    <p class="text-muted font-13">
                    {{$result->bio}}
                    </p>

                    <hr/>
                    <div class="text-left">
                        <p class="text-muted"><strong>Full Name :</strong> <span class="ml-2">{{ucfirst($result->first_name)}} {{ucfirst($result->last_name)}}</span></p>
                        <!-- <p class="text-muted"><strong>Date Of Birth :</strong> <span class="ml-2">30-01-1985</span></p> -->
                        <p class="text-muted"><strong>Mobile :</strong><span class="ml-2">{{$result->mobile}}</span></p>
                        <p class="text-muted"><strong>Email :</strong> <span class="ml-2">{{$result->email}}</span></p>
                        <p class="text-muted"><strong>Site Location :</strong> <span class="ml-2">{{$result->industry_id}}</span></p>                                        
                    </div>
                </div>
            </div>

        </div> 
    </div>
        
    </div>
</div>

 <!-- -------Site Details Start -------->

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
        <div class="page-title-box">
            <!-- <div class="page-title-right" style="display: block"> <a href="add-site.html" class="btn btn-dark btn-rounded"><span class="uil uil-plus"></span> Add Site</a> </div> -->
            <h4 class="page-title">Sites</h4>
        </div>
        </div>
        <div class="col-xl-12 col-lg-12">
        <div class="card">
            <div class="card-body">
            <div class="table-responsive">
                <table id="datatable-buttons" class="table table-bordered table-centered mb-0">
                <thead>
                    <tr>
                    <th>Sites</th>
                    <th>Manager</th>
                    <th>Contact Number</th>
                        <th>Cleaning Company</th>
                    <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>

                @foreach($siteresult as $results)
                    <tr>
                        <td><a href="sites-details.html">{{$results->name}}</a></td>
                        <td><a href="staffs-details.html">{{ucfirst($results->first_name)}} {{ucfirst($results->last_name)}}</a></td>
                        <td>{{$results->mobile}}</td>
                        <td><a href="javascript:void(0);">Tesla Cleaners</a></td>
                        <!-- <td class="table-action text-center"><div class="col-auto"> <a href="javascript:void(0);" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-danger btn-lg p-0 pr-2" data-original-title="Delete"> <i class="uil uil-multiply"></i> </a> <a href="add-site.html" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-muted btn-lg p-0 pr-2" data-original-title="Edit"> <i class="uil uil-edit-alt"></i> </a> 
                            <a href="chat.html" data-toggle="tooltip" data-placement="bottom" title="" class="btn btn-link text-muted btn-lg p-0" data-original-title="Chat"> <i class="mdi mdi-chat"></i> </a>
                            </div>
                        </td> -->
                    </tr>  
                    
                    @endforeach
                    
                </tbody>
                </table>
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
</div>


@endsection
