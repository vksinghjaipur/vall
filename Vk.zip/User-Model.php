<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\SoftDeletes;
use Auth;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_role_id',
        'parent_id',
        'first_name',
        'last_name',
        'full_name',
        'email',
        'mobile',
        'mobile_1',
        'password',
        'avtar',
        'status',
        'is_favourite',
    ];

    
    public function meta()
    {
        return $this->hasOne(UserMeta::class);
    }

    public function parent()
    {
        return $this->hasOne(User::class,'id','parent_id');
        //return $this->hasOne(User::class,'parent_id','id'); //old
    }

    /* client's sites */
    public function sites()
    {
        return $this->hasMany(Sites::class,'client_id');
    }

    /* site manager's site */
    public function site()
    {
        return $this->belongsTo(Sites::class,'id','manager_id');
    }

    /* cleaning companies's details */
    public function companyDetails()
    {
        return $this->hasOne(Cleaningcompanies::class);
    }  

    /* cleaning companies's site */
    public function assignSites()
    {
        return $this->hasMany(AssignSite::class);
    }

    protected $appends = ['cc_favourite'];

    public function getCcFavouriteAttribute($value)
    {
        $isFavourite = 0;
        $favClientIdArray = \Auth::user()->companyDetails->favourite_clients ?? [];
        if(!empty($favClientIdArray) && count($favClientIdArray)>0){
            if(in_array($this->id,$favClientIdArray)){
                $isFavourite = 1;
            }
        }
        return $isFavourite;
    }



    public static function boot() {
        parent::boot();
        /* static::creating(function($model) {
           $user = Auth::user();
           $model->created_by = $user->id;
           //$model->updated_by = $user->email;
        }); */
        static::deleting(function($model) {
            $user = Auth::user();
            $model->email = "delete_".$model->id."_".$model->email;
           $model->mobile = "delete_".$model->id."_".$model->mobile;
           $model->save();
        });
    }
    
    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
