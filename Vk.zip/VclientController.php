<?php 

namespace App\Http\Controllers; 

use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;  
use View,Session,DB,Auth,Validator,Response;

use App\Models\User;
use App\Models\UserMeta;
use App\Models\Sites;
 


class ClientController extends Controller 
{ 
    public $modalClass;
    public $viewPath;

    public function __construct()
    {
        $this->modalClass   =   "client";
        $this->viewPath     =   "client";

        View::share('viewPath', $this->viewPath);
    }
    
    public function index(Request $request)
    { 
        //$result=DB::table('users')->get();
        $result=DB::table('users')
        ->join('user_metas','user_metas.user_id','=','users.id')
        ->select('users.*', 'user_metas.industry_id', 'user_metas.bio')
        ->where('users.user_role_id',2)
        ->where('users.deleted_at', NULL)
        ->orderBy('users.id', 'DESC')
        ->paginate(3);

    
        //echo "<pre>"; print_r($users);exit;
        //return view('dashboard.index', compact('userinfo'));
        return view($this->viewPath.'.index', compact('result'));    
          
    }

    public function show($id)
    { 

        $result = User::find($id);
           if(!$result){
           // $this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index')->with('success','User not found!');
        }


    	// $this->authorize('show-store', User::class);
        //$result = User::with(site_mngr);
        $result=DB::table('users')
        ->join('user_metas','user_metas.user_id','=','users.id')
        ->select('users.*', 'user_metas.industry_id', 'user_metas.bio')
        ->where('users.id',$id)->first();

        //$siteresult = Sites::
        $siteresult=DB::table('sites')
        ->join('users', 'users.site_id', '=', 'sites.id')
        ->select('sites.*', 'users.id','users.first_name','users.last_name', 'users.full_name','users.mobile','users.avtar')
        //->where('Sites.status', '!=' , '2')
        ->where('sites.client_id', $id)
        ->get();
       // echo "<pre>"; print_r($siteresult); exit; 

        return view($this->viewPath.'.show',compact('result','siteresult'));
    }

    public function create()
    {
        // $this->authorize('create-user', User::class);
    $industries = DB::table('industries')->get();
        return view($this->viewPath.'.create',compact('industries'));
    }

    public function store(Request $request)
    {
        $data   =   $request->all();
        Validator::extend('mobile_valid', function ($attribute, $value, $parameters, $validator) {
            return preg_match('/^(\+61\d{0,9})|(\d{0,9})$/', $value); //regex:/^(\+61\d{0,9})|(\d{0,9})$/
        });
        $validator = Validator::make($data, [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'mobile' => "required|mobile_valid|unique:users,mobile",
            'mobile_1' => "sometimes|mobile_valid",
            'email' => "required|string|email|max:255|unique:users,email",
            'industry_id' => 'required',
            'password' => 'required|string|min:6',
            'confirm_password' => 'required|same:password',
            'avtar' => 'sometimes|image|max:2048',
            'bio' => 'sometimes|max:500',
        ],[
            'mobile.mobile_valid' =>  'Enter a valid mobile number',
            'mobile_1.mobile_valid' =>  'Enter a valid alternate mobile number',
            'industry_id.required' =>  'Select a industry type',
            'avtar.max' =>  'Avtar can not be more then 2mb',
        ]);

        if ($validator->fails()) {
			return Response::json(array(
                'success' => false,
                'errors' => $validator->getMessageBag()->toArray()
            ));
            //return redirect()->back()->withInput($request->all())->withErrors($validator->errors());
		} else {
            
            $request->merge(['password' => bcrypt($request->password)]);
            
            $data   =   $request->all();
            $data['user_role_id']   =   2;
            if(!isset($request->status)){
                $data['status']   =   0;
            }


        if($request->file('avtar')){
            $file= $request->file('avtar');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('public/users/images'), $filename);
            $data['avtar']= $filename;
        }


                
            $data['full_name'] = $request->get('first_name')." ".$request->get('last_name');
            $user = User::create($data);
            $metaData['user_id']        =   $user->id;
            $metaData['industry_id']    =   $request->industry_id;
            $metaData['bio']            =   $request->bio;
            $user->meta()->create($metaData);

            Session::flash('success', 'Client added successfully.');

            return Response::json(array('success' => true, 'message'=>'Client added successfully.'));
        }
    }
    

    public function edit($id=null)
    { 

                $result = User::find($id);
           if(!$result){
           // $this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index')->with('success','User not found!');
        }



    	// $this->authorize('edit-user', User::class);
    	//$result = User::with('meta')->where($id);
         $industries = DB::table('industries')->get();
        $result=DB::table('users')
        ->join('user_metas','user_metas.user_id','=','users.id')
        ->select('users.*', 'user_metas.industry_id', 'user_metas.bio')
        ->where('users.id',$id)->first();
    
        //echo "<pre>"; print_r($result); exit; 

        return view($this->viewPath.'.edit',compact('result','industries'));
    }

    public function update(Request $request, $id)
    {
        $result = User::find($id);
        //echo "<pre>"; print_r($result); exit;
        if($request->file('avtar')){
            $fileName = $request->file('avtar')->store(USER_IMAGE_ROOT_PATH);
            $result['avtar']   =   $fileName;
        }
        $result->first_name = $request->first_name;
        $result->last_name = $request->last_name;
        $result->mobile = $request->mobile;
        $result->email = $request->email;
        $result->save(); 
              
        $result2 = UserMeta::find($id);
        //echo ($id); exit;
        $result2 = UserMeta::where('user_id',$id)->first();
        $result2->bio = $request->input('bio');
        $result2->industry_id = $request->input('industry_id');
        $result2->update(); 
        // DB::table('user_metas')->where('id',$userId)->update($result);

        return redirect()->route($this->viewPath.'.index')->with('success','User has been updated successfully');
    }

    public function updatePassword(Request $request,$id)
    {
    	// $this->authorize('edit-user', User::class);
    	$result = User::find($id);

        if(!$result){
        	//$this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index');
        }

        $request->merge(['password' => bcrypt($request->get('password'))]);
        $store->update($request->all());
        $this->flashMessage('check', 'Store password updated successfully!', 'success');
        return redirect()->route($this->viewPath.'.index');
    }

    public function editPassword($id)
    { 
    	// $this->authorize('edit-user', User::class);
    	$result = User::find($id);

    	if(!$result){
        	//$this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index');
        }              	               
        return view($this->viewPath.'.edit_password',compact('result'));
    }

   
    public function destroy($id)
	{

                $result = User::find($id);
           if(!$result){
           // $this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index');
        }



		$result = User::where('id',$id)->delete();
        return back()->with('success','User Deleted successfully!');
	}


    public function favourite(Request $request, $id)
    {
        $details=User::where('id',$id)->first();
        if($details->is_favourite==1){
            $data['is_favourite']="0";
            $msg="Unfavourite Client Successfully";

        } else{
            $data['is_favourite']="1";
            $msg="Favourite Client Added Successfully";
        
        }
        User::where('id',$id)->update($data);

        return back()->with('success', $msg);
    }

}