<?php 

namespace App\Http\Controllers; 

use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;
use App\Mail\Registration;  
use View,Session,DB,Auth,Validator,Response,File,Mail,Redirect,Hash;

use App\Models\User;
use App\Models\UserMeta;
use App\Models\Sites;
use App\Models\Industry;
use App\Models\AssignSite;
use App\Models\Cleaningcompanies;
use App\Models\ManagerSite;
use App\Models\CleanerSite;

//for V Notification
use Notification;
use App\Notifications\SubAdminNotification;
use App\Models\MyNotification;
use Carbon\Carbon;


class SubadminController extends Controller 
{ 
    public $modalClass;
    public $viewPath;

    public function __construct()
    {
        $this->modalClass   =   "subadmin";
        $this->viewPath     =   "subadmin";
        View::share('viewPath', $this->viewPath);
    }
    
    public function index(Request $request)
    { 
        $userDetails    =   Auth::user();
        
        $DB             =  User::query();
        if($userDetails->parent_id == ADMIN_ID){
            $parentId   =   $userDetails->id;
            $DB->whereIn('user_role_id',[CLIENT_ROLE,SITE_MANAGER_ROLE]);
        }else{
            if($userDetails->user_role_id == CLEANING_MANAGER_ROLE){
                $DB->whereIn('user_role_id',[CLEANER_ROLE]);
                $parentId   =   $userDetails->parent_id;
            }else if($userDetails->user_role_id == CLEANING_COMPANY_ROLE){
                $DB->whereIn('user_role_id',[CLEANING_MANAGER_ROLE,CLEANER_ROLE]);
                $parentId   =   $userDetails->id;
            }else{
                $parentId   =   $userDetails->parent_id;
                $DB->whereIn('user_role_id',[CLIENT_ROLE,SITE_MANAGER_ROLE]);
            }
        }

        $DB->with('meta')->where('parent_id', $parentId);

        $result =  $DB->latest()->paginate(PAGE_LIMIT);
        //pr($userId); die;
        return view($this->viewPath.'.index', compact('result'));    
    }

    public function show(Request $request,$id)
    { 
       
        $result = User::with('meta')->find($id);
        //pr($result);die();
        if(empty($result)){
            return Redirect::back()->with('error','Client not found!');
        }
        if($result->user_role_id == CLIENT_ROLE){
            $siteresult =   Sites::with('manager','cleaningCompanies.companyDetails')->where('client_id',$result->id)->get();
        }elseif($result->user_role_id == CLEANING_MANAGER_ROLE){
            $managerSiteIds     =   ManagerSite::where('user_id',$result->id)->pluck('site_id','site_id')->toArray();
            $siteresult         =   Sites::with('manager','cleaningCompanies.companyDetails')->whereIn('id',$managerSiteIds)->get();
        }else{
            $siteresult         =   Sites::with('manager','cleaningCompanies.companyDetails')->where('client_id',$result->parent_id)->where('manager_id',$result->id)->get();
        }

        if(isset($request->read))
        {
            $userUnreadNotification = MyNotification::where('id',$request->read)->first();
            if($userUnreadNotification) {  
                    if ($userUnreadNotification->read_at == '') {
                        $userUnreadNotification->read_at = Carbon::now();
                        $userUnreadNotification->save();
                    } 
            }
        
        }
        return view($this->viewPath.'.show',compact('result','siteresult'));
    }

    public function create(Request $request)
    {
        
        $userDetails = Auth::user();

        
        if($userDetails->user_role_id==CLEANING_COMPANY_ROLE){
            $asignSites = AssignSite::where('company_user_id',$userDetails->id)->pluck('site_id', 'site_id')->toArray();
            $Sites = Sites::whereIn('id',$asignSites)->get();
        }
        else{
            $asignSitesManager = ManagerSite::where('user_id',$userDetails->id)->pluck('site_id', 'site_id')->toArray();
            $Sites = Sites::whereIn('id',$asignSitesManager)->get();
        }
        

        return view($this->viewPath.'.create',compact('Sites','userDetails'));
    }

    public function store(Request $request)
    {
        $userId         =  Auth::id();
        $userDetails    =  Auth::user();
        if($userDetails->parent_id == ADMIN_ID){
            $parentId   =   $userDetails->id;
        }else{
            if($userDetails->user_role_id == CLEANING_COMPANY_ROLE){
                $parentId   =   $userDetails->id;
            }else{
                $parentId   =   $userDetails->parent_id;
            }
        }
        
        $data   =   $request->all();
        
        Validator::extend('mobile_valid', function ($attribute, $value, $parameters, $validator) {
            return preg_match('/^(\+61\d{0,9})|(\d{0,9})$/', $value); //regex:/^(\+61\d{0,9})|(\d{0,9})$/
        });
        $validator = Validator::make($data, [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'position' => 'required|string|max:255',
            'mobile' => "required|mobile_valid|unique:users,mobile",
            'mobile_1' => "sometimes|mobile_valid",
            'email' => "required|string|email|max:255|unique:users,email",
            'password' => 'required|string|min:6',
            'confirm_password' => 'required|same:password',
            'avtar' => 'sometimes|image|max:2048',
            'bio' => 'sometimes|max:500',
        ],[
            'mobile.mobile_valid' =>  'Enter a valid mobile number',
            'mobile_1.mobile_valid' =>  'Enter a valid alternate mobile number',
            'avtar.max' =>  'Avtar can not be more then 2mb',
        ]);

        if ($validator->fails()) {
            return Response::json(array(
                'success' => false,
                'errors' => $validator->getMessageBag()->toArray()
            ));
            //return redirect()->back()->withInput($request->all())->withErrors($validator->errors());
        } else {
            $pstring = $request->password;
            $request->merge(['password' => bcrypt($request->password)]);
            
            $data   =   $request->all();
            if($userDetails->user_role_id == CLIENT_ROLE) {
                $data['user_role_id']   =   CLIENT_ROLE;
            }
            elseif(($userDetails->user_role_id == CLEANING_COMPANY_ROLE) || ($userDetails->user_role_id == CLEANING_MANAGER_ROLE)) {
                if($data['position'] == "Cleaner") {
                    $data['user_role_id']   =  CLEANER_ROLE;
                }else{
                    $data['user_role_id']   =  CLEANING_MANAGER_ROLE;
                }
            }
            else{
                $data['user_role_id']   =  0;
            }
            $data['status']         =   $request->status ?? 0;

            if($request->file('avtar')){
                $file       = $request->file('avtar');
                $filename   = time().$file->getClientOriginalName();
                $folderPath = date("Y").DS.strtoupper(date("M")).DS;
                $path       = USER_IMAGE_ROOT_PATH.$folderPath;
                if(! File::exists($path)) {
                    File::makeDirectory($path, $mode = 0777, true, true);
                }
                $file->move($path, $filename);
                $data['avtar'] = $folderPath.$filename;
            }

            // $pId  =  User::where('id',Auth::User()->parent_id)->first();

            $data['full_name'] = $request->get('first_name')." ".$request->get('last_name');
            $data['parent_id'] = $parentId;
            $user = User::create($data);
            
            $metaData['user_id']        =   $user->id;
            $metaData['bio']            =   $request->bio;
            $metaData['position']       =   $request->position;
            $user->meta()->create($metaData);
           
            if(!empty(Auth::user()->user_role_id==CLEANING_COMPANY_ROLE || Auth::user()->user_role_id==CLEANING_MANAGER_ROLE )){
                if(Auth::user()->user_role_id==CLEANING_COMPANY_ROLE) {
                    $parentId = Auth::user()->id;
                }
                else{
                    $parentId = Auth::user()->parent_id;
                }
                
                if(!empty($request->site_id)) {
                    $siteIds = $request->site_id;

                    /* For Notification Send  start*/ 
                    $siteManagers_id = Sites::with('manager')->whereIn('id',$siteIds)->pluck('manager_id', 'manager_id')->toArray();                   
                                        
                     foreach($siteManagers_id as $manager_id) {
                        $siteManager_details = User::where('id',$manager_id)->first();
                        if(!empty($siteManager_details)){
                            $siteManager_details->notify(new SubAdminNotification($user));
                        }   
                     }        
                    /* For Notification Send End*/ 
                
                    foreach($siteIds as $siteid) {    
                        $manager_data['site_id']                =   $siteid;
                        $manager_data['cleaning_company_id']    =   $parentId;
                        $manager_data['user_id']                =   $user->id;
                        $ccPositionCleaner = CC_POSITION_LIST[1] ?? '';
                        if((Auth::user()->user_role_id == CLEANING_COMPANY_ROLE) && ($data['position'] == $ccPositionCleaner)) {
                            CleanerSite::insert($manager_data);
                        }
                        elseif(Auth::user()->user_role_id == CLEANING_MANAGER_ROLE) {
                            CleanerSite::insert($manager_data);
                        }
                        else{
                            ManagerSite::insert($manager_data);
                        }
                    }
                }
            }
             
            Mail::to($request->email)->send(new Registration($user, $pstring));
            
            //$manager_id->notify(new SubAdminNotification($user));
                      

            Session::flash('success', 'User added successfully.');

            return Response::json(array('success' => true, 'message'=>'User added successfully.'));
        }
    }
    

    public function edit($id=null) { 

        $result = User::with('meta')->find($id);
        if(empty($result)){         
            return Redirect::back()->with('error','Sub-Admin not found!');
        }

        $userDetails    =   Auth::user();
        $userId         =   $userDetails->id;

        if($userDetails->user_role_id == CLEANING_COMPANY_ROLE){
            $companySiteList    = AssignSite::where('company_user_id',$userDetails->id)->pluck('site_id', 'site_id')->toArray();
            $siteList           = Sites::whereIn('id',$companySiteList)->get();

            $ccPositionCleaner = CC_POSITION_LIST[0] ?? '';
            if($result->meta->position == $ccPositionCleaner){
                $selectedSites      = ManagerSite::where('user_id',$result->id)->pluck('site_id', 'site_id')->toArray();
            }else{
                $selectedSites      = CleanerSite::where('user_id',$result->id)->pluck('site_id', 'site_id')->toArray();
            }

        }else if($userDetails->user_role_id == CLEANING_MANAGER_ROLE){
            $managerSiteList  = ManagerSite::where('user_id',$userDetails->id)->pluck('site_id', 'site_id')->toArray();
            $siteList         = Sites::whereIn('id',$managerSiteList)->get();

            $selectedSites    = CleanerSite::where('user_id',$result->id)->pluck('site_id', 'site_id')->toArray();
        }else{
            $siteList         = [];
            $selectedSites    = [];
        }
        //pr($selectedSites); die;
        
        
        return view($this->viewPath.'.edit',compact('result','siteList','userDetails','selectedSites'));
    }

    public function update(Request $request, $id) {
        $userDetails    =   Auth::user();

        $result = User::with('meta')->find($id);
        if(empty($result)){
            return back()->with('error', 'Invalid Request!');
        }
        
        $data   =   $request->all();
        
        Validator::extend('mobile_valid', function ($attribute, $value, $parameters, $validator) {
            return preg_match('/^(\+61\d{0,9})|(\d{0,9})$/', $value); //regex:/^(\+61\d{0,9})|(\d{0,9})$/
        });
        $validator = Validator::make($data, [
            'first_name'    => 'required|string|max:255',
            'last_name'     => 'required|string|max:255',
            'mobile'        => "required|mobile_valid|unique:users,mobile,$id",
            'mobile_1'      => "sometimes|mobile_valid",
            'email'         => "required|string|email|max:255|unique:users,email,$id",
            'avtar'         => 'sometimes|image|max:2048',
            'bio'           => 'sometimes|max:500',
        ],[
            'mobile.mobile_valid'   =>  'Enter a valid mobile number',
            'mobile_1.mobile_valid' =>  'Enter a valid alternate mobile number',
            'avtar.max'             =>  'Avtar can not be more then 2mb',
        ]);

        if ($validator->fails()) {
            return Response::json(array(
                'success' => false,
                'errors' => $validator->getMessageBag()->toArray()
            ));
            //return redirect()->back()->withInput($request->all())->withErrors($validator->errors());
        } else {
            if($request->file('avtar')){
                $file       = $request->file('avtar');
                $filename   = time().$file->getClientOriginalName();
                $folderPath = date("Y").DS.strtoupper(date("M")).DS;
                $path       = USER_IMAGE_ROOT_PATH.$folderPath;
                if(! File::exists($path)) {
                    File::makeDirectory($path, $mode = 0777, true, true);
                }
                if($file->move($path, $filename)){
                    if(!empty($result->avtar) && File::exists(USER_IMAGE_ROOT_PATH . $result->avtar)){
                        File::delete(USER_IMAGE_ROOT_PATH . $result->avtar);
                    }
                    $result->avtar   = $folderPath.$filename;
                }
            }

            $result->first_name = $request->first_name;
            $result->last_name  = $request->last_name;
            $result->full_name  = $request->first_name." ".$request->last_name;
            $result->mobile     = $request->mobile;
            $result->mobile_1   = ($request->mobile_1 ?? '');
            $result->email      = $request->email;
            $result->status     = $request->status ?? 0;
            $result->save(); 
            
            if($request->bio){
                $result2 = UserMeta::find($result->meta->id);
                $result2->bio       = $request->bio;
                if($request->position){
                    $result2->position  = $request->position;
                }
                $result2->update(); 
            }

            if(in_array($userDetails->user_role_id,[CLEANING_COMPANY_ROLE,CLEANING_MANAGER_ROLE])){
                $ccPositionCleaner = CC_POSITION_LIST[1] ?? '';
                
                if($userDetails->user_role_id == CLEANING_COMPANY_ROLE){
                    $cleaningCompanyUserId      =   $userDetails->id;
                    
                    if(strtolower($result->meta->position) == strtolower($ccPositionCleaner)){
                        $this->update_sites_cleaner($request->site_id,$cleaningCompanyUserId,$id);
                    }else{
                        $this->update_sites_manager($request->site_id,$cleaningCompanyUserId,$id);
                    }
                }else{
                    $cleaningCompanyUserId      =   $userDetails->parent_id;

                    $this->update_sites_cleaner($request->site_id,$cleaningCompanyUserId,$id);
                }
            }
            
            /* if(!empty(Auth::user()->user_role_id==CLEANING_COMPANY_ROLE || Auth::user()->user_role_id==CLEANING_MANAGER_ROLE )){
                if(Auth::user()->user_role_id==CLEANING_COMPANY_ROLE) {
                    $parentId = Auth::user()->id;
                }
                else{
                    $parentId = Auth::user()->parent_id;
                }
                $userId         =  Auth::id();
                $site_id = $request->site_id;
                $position = User::with('meta')->find($id);

                if($position->meta->position=='Account Manager')
                {
                    $this->update_sites_manager($site_id,$parentId,$userId,$id);
                }
                else
                {
                    $this->update_sites_cleaner($site_id,$parentId,$userId,$id);
                }
            } */

            return redirect()->route($this->viewPath.'.index')->with('success','User updated successfully.');
        }
    }

    public function update_sites_manager($siteIds, $cleaningCompanyUserId, $id) {
        if(!empty($siteIds)){
            $updatedAssignSiteIds   =   [];
            foreach($siteIds as $siteId) {
                $assignSite = ManagerSite::firstOrCreate(
                    ['site_id' => $siteId, 'cleaning_company_id' => $cleaningCompanyUserId, 'user_id' => $id]
                );
                $updatedAssignSiteIds[$assignSite->id] = $assignSite->id;  
                
                //remove duplicate data from soft deleted
                ManagerSite::where('site_id',$siteId)->where('cleaning_company_id',$cleaningCompanyUserId)->where('user_id',$id)->onlyTrashed()->forceDelete();
            }
            if(!empty($updatedAssignSiteIds)){
                ManagerSite::where('cleaning_company_id',$cleaningCompanyUserId)->where('user_id', $id)->whereNotIn('id',$updatedAssignSiteIds)->delete();
            }
        }
        return true;
    }


    public function update_sites_cleaner($siteIds, $cleaningCompanyUserId, $id) {
        if(!empty($siteIds)){
            $updatedAssignSiteIds   =   [];
            foreach($siteIds as $siteId) {
                $assignSite = CleanerSite::firstOrCreate(
                    ['site_id' => $siteId, 'cleaning_company_id' => $cleaningCompanyUserId, 'user_id' => $id]
                );
                $updatedAssignSiteIds[$assignSite->id] = $assignSite->id;  

                //remove duplicate data from soft deleted
                CleanerSite::where('site_id',$siteId)->where('cleaning_company_id',$cleaningCompanyUserId)->where('user_id',$id)->onlyTrashed()->forceDelete();
            }
            if(!empty($updatedAssignSiteIds)){
                CleanerSite::where('cleaning_company_id',$cleaningCompanyUserId)->where('user_id', $id)->whereNotIn('id',$updatedAssignSiteIds)->delete();
            }
        }
        return true;
    }



    public function updatePassword(Request $request,$id) {
        // $this->authorize('edit-user', User::class);
        $result = User::find($id);

        if(empty($result)){
            return Redirect::back()->with('error','Sub-Admin not found!');
        }

        $request->merge(['password' => bcrypt($request->get('password'))]);
        $store->update($request->all());
        
        return redirect()->route($this->viewPath.'.index')->with('success','Password updated successfully.');
    }

    public function editPassword($id) { 
        // $this->authorize('edit-user', User::class);
        $result = User::find($id);

        if(!$result){
            return Redirect::back()->with('error','Client not found!');
        }                              
        return view($this->viewPath.'.edit_password',compact('result'));
    }

   
    public function destroy($id) {

        $result = User::find($id);
        if(empty($result)){
            return Redirect::back()->with('error','User not found!');
        }
        $result->delete();

        //return Redirect::back()->with('success','Sub-Admin deleted successfully.');
        return redirect()->route('subadmin.index')
                        ->with('success','User deleted successfully');    
        
    }


    public function favourite(Request $request, $id) {
        $details=User::where('id',$id)->first();
        if($details->is_favourite==1){
            $data['is_favourite']="0";
            $msg="Unfavourite Sub-Admin Successfully";

        } else{
            $data['is_favourite']="1";
            $msg="Favourite Sub-Admin Added Successfully";
        
        }
        $details->update($data);
        return back()->with('success', $msg);
    }

     public function import(Request $request){
        $company_id = Auth::user()->id;
        return view($this->viewPath.'.import',compact('company_id'));
        
    }

   public function importCleaner(Request $request){
        $company_user_id = $request->company_id;
        $companySites = AssignSite::where('company_user_id',$company_user_id)->pluck('site_id')->toArray();
        $header = null;
        $data = array();
        $filename = $request->file;
        if(!file_exists($filename) || !is_readable($filename)){
            return back()->with('error','please enter valid file');
        }

        if(($handle = fopen($filename, 'r')) !== false)
        {
            while (($row = fgetcsv($handle)) !== false)
            {
                if(!$header){
                    $header = $row;
                }else{
                    $data[] = $row;
                }

            }
            fclose($handle);

            if(count($header) != 8){
                 return back()->with('error','Please define data column properly.');
            }
            
            //---------------------------------------validate file data-----------------------------------//
            $count = 1;
            foreach($data as $cleaner){
                $userdata = array();
                $userdata['site_ids'] = $cleaner[0];
                $userdata['first_name'] = $cleaner[1];
                $userdata['last_name'] = $cleaner[2];
                $userdata['email'] = $cleaner[3];
                $userdata['mobile'] = $cleaner[4];
                $userdata['alter_mobile'] = $cleaner[5];
                $userdata['description'] = $cleaner[6];
                $userdata['password'] = $cleaner[7];
                Validator::extend('mobile_valid', function ($attribute, $value, $parameters, $validator) {
                    return preg_match('/^(\+61\d{0,9})|(\d{0,9})$/', $value); //regex:/^(\+61\d{0,9})|(\d{0,9})$/
                });
                $validator = Validator::make($userdata, [
                    'first_name' => 'required|string|max:255',
                    'last_name' => 'required|string|max:255',
                    'mobile' => "required|mobile_valid|unique:users,mobile",
                    'alter_mobile' => "sometimes|mobile_valid",
                    'email' => "required|string|email|max:255|unique:users,email",
                    'password' => 'sometimes|string|min:6',
                    'description' => 'sometimes|max:500',
                ],[
                    'mobile.mobile_valid' =>  'Enter a valid mobile number',
                    'alter_mobile.mobile_valid' =>  'Enter a valid alternate mobile number',
                ]);

                $count++;
                if(!empty($userdata['site_ids'])) {
                    $siteIds = explode(",",$userdata['site_ids']);
                    foreach($siteIds as $siteid) {    
                        if(!in_array($siteid, $companySites)){
                            Session::flash('site_error', 'site id '.$siteid.' not found in company sites.');
                            return redirect()->back()->withErrors($validator->errors())->with(['row_num'=>$count]);
                        }      
                    }
                }
                if($validator->fails()) {
                    return redirect()->back()->withErrors($validator->errors())->with(['row_num'=>$count]);
                } 
            }

            //-----------------------------------insert file data--------------------------------------//

            DB::beginTransaction();
            try{
                foreach($data as $key => $cleaner){
                    $random_password = '';
                    $userdata = array();
                    $userdata['site_ids'] = $cleaner[0];
                    $userdata['first_name'] = $cleaner[1];
                    $userdata['last_name'] = $cleaner[2];
                    $userdata['email'] = $cleaner[3];
                    $userdata['mobile'] = $cleaner[4];
                    $userdata['alter_mobile'] = $cleaner[5];
                    $userdata['description'] = $cleaner[6];
                    $userdata['password'] = $cleaner[7];
                    if(!empty($userdata['password'])){
                        $userdata['password'] = Hash::make($userdata['password']);
                    }else{
                        $random_password = substr(md5(time()), 0, 8);
                        $userdata['password'] = Hash::make($random_password);
                    }
                    
                    $cleaner_user['first_name'] = $userdata['first_name'];
                    $cleaner_user['last_name'] = $userdata['last_name'];
                    $cleaner_user['full_name'] = $userdata['first_name']." ".$userdata['last_name'];
                    $cleaner_user['email'] = $userdata['email'];
                    $cleaner_user['mobile'] = $userdata['mobile'];
                    $cleaner_user['mobile_1'] = $userdata['alter_mobile'];
                    $cleaner_user['parent_id'] = $company_user_id;
                    $cleaner_user['user_role_id']   =  CLEANER_ROLE;
                    $cleaner_user['password'] = $userdata['password'];
                    $cleaner_user['status']  = 1;
                    $user = User::create($cleaner_user);

                    $user_meta = new UserMeta();
                    $user_meta->user_id = $user->id;
                    $user_meta->bio =   $userdata['description'];
                    $user_meta->position = 'cleaner';
                    $user_meta->save();
                    
                    if(!empty($userdata['site_ids'])) {
                        $siteIds = explode(",",$userdata['site_ids']);
                        foreach($siteIds as $siteid) {    
                            $site_data['user_id']                =   $user->id;
                            $site_data['site_id']                =   $siteid;
                            $site_data['cleaning_company_id']    =   $company_user_id;
                            CleanerSite::insert($site_data);
                        }
                    }


                    if($random_password != ''){
                        Mail::to($userdata['email'])->send(new Registration($user, $random_password));
                    }
                    
                }
                DB::commit();
                return back()->with('success','Data uploaded successfully.');
            }
            catch(\Exception $e){
                DB::rollback();
                return back()->with('error',$e);
            }
        }else{
            return back()->with('error','please enter valid file');
        }
    }    

}