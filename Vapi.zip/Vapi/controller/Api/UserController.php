<?php

namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use DateTime;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Notification;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class UserController extends APIController
{
         
    //V Notification List
    public function notificationList(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }  
        
        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
        $limit = $request->limit ? $request->limit : 6;
        $page = $request->page && $request->page > 0 ? $request->page : 1;

        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);

        
        $notificationlist=DB::table('notifications')->where('notifiable_id',$userid)->orderBy('id','desc')->paginate($limit);
        //echo'<pre>';print_r($notificationlist);exit;

        $unreadmessage=DB::table('notifications')->where('notifiable_id',$userid)->where('read_at',NULL)->count();

        $notificationData=array();
        foreach ($notificationlist as $key => $value)
        {
            $content = json_decode($value->data,TRUE);

            $notificationData[$key]['id']=isset($value->id)?$value->id:'';
            $notificationData[$key]['title']=isset($content['title'])?$content['title']:'';
            $notificationData[$key]['message']=isset($content['text'])?$content['text']:'';
            $notificationData[$key]['type']=isset($value->type)?$value->type:'';
            $notificationData[$key]['read_at']=isset($value->read_at)?$value->read_at:'';
            $notificationData[$key]['created_at']=isset($value->created_at)?$value->created_at:'';
        }

        $resultArray['status']=1;
        $resultArray['message']=trans('api.Notification list');
        $resultArray['data']=$notificationData;
        $resultArray['unread']=$unreadmessage;
        $resultArray['current_page']=$notificationlist->currentPage();
        $resultArray['total_page']=$notificationlist->lastPage();
        echo json_encode($resultArray); exit;     
      
    }

    //V Notification Read
    public function notificationRead(Request $request)
    {
        
        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'notifiable_id'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }  

        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);

       
        $notificationlist=DB::table('notifications')
                        ->where('id',$request->notifiable_id)
                        ->update(
                            ['read_at'=>now()]
                        );

        $unreadmessage=DB::table('notifications')->where('notifiable_id',$request->user_id)->where('read_at',NULL)->count();
     
        $resultArray['status']=1;
        $resultArray['message']=trans('api.Notification read successfully');
        $resultArray['unread']=$unreadmessage;
        echo json_encode($resultArray); exit;     
    }


    //V Notification Delete
    public function notificationDelete(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
            'notifiable_id'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }  
        
        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);

      
        if(!empty($request->notifiable_id))
        {
            
            if($request->notifiable_id=='all')
            {
                DB::table('notifications')->where('notifiable_id',$request->user_id)->delete(); 
            }
            else
            {
                $notificationdelete= explode(',', $request->notifiable_id);

                foreach ($notificationdelete as $key => $delete)
                {
                    DB::table('notifications')
                            ->where('id',$delete)
                            ->delete();
                }
            }

        }

        $unreadmessage=DB::table('notifications')->where('notifiable_id',$request->user_id)->where('read_at',NULL)->count();
            $resultArray['status']=1;
            $resultArray['message']=trans('api.Notification delete successfully');
            $resultArray['unread']=$unreadmessage;
            echo json_encode($resultArray); exit; 
    }


    public function favorite(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
            'doctor_id'=>'required',
            
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $doctorId = isset($request->doctor_id) && !empty($request->doctor_id) ? $request->doctor_id: '';
            
            $checkfavorite=DB::table('favorites')->whereRaw("(user_id='".$userId."' AND doctor_id='".$doctorId."')")->first();

            if(empty($checkfavorite))
            {
                DB::table('favorites')->insert([
                                        'user_id'=>$userId,
                                        'doctor_id'=>$doctorId
                                        ]);
                $message='Favorite';
                $isfavorite=1; 
            }
            else
            {
                DB::table('favorites')->whereRaw("(user_id='".$userId."' AND doctor_id='".$doctorId."')")->delete();
                $isfavorite=0;
                $message='Unfavorite';
            }

                $resultArray['status']='1';
                $resultArray['message']=$message;
                $resultArray['is_favorite']=$isfavorite;
                return response()->json($resultArray); exit;    
    }


    public function favoriteList(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $limit = $request->limit ? $request->limit : 20;
            $page = $request->page && $request->page > 0 ? $request->page : 1;             
           
            $favoriteLists=DB::table('users')
            ->join('favorites', 'favorites.doctor_id', '=', 'users.id')
            ->join('userprofiles', 'userprofiles.user_id', '=', 'users.id')
            ->where('favorites.user_id',$userId)
            ->select('users.*', 'userprofiles.*')
            ->orderBy('users.id', 'DESC')->paginate($limit);

             //favoritedata
            $checkfavorite = array();
            if(!empty($userId)){
            $checkfavorite=DB::table('favorites')->where('user_id',$userId)->pluck('doctor_id')->toArray();
            }
                       
            if(count($favoriteLists)>0)
            {
                $favoritedata=array();
                foreach ($favoriteLists as $p => $favoriteList)
                {  

                $favoritedata[$p]['doctor_id']=$favoriteList->user_id;
                $favoritedata[$p]['name']=$favoriteList->name;
                $favoritedata[$p]['username']=$favoriteList->username;
                $favoritedata[$p]['email']=$favoriteList->email;
                $favoritedata[$p]['mobile']=$favoriteList->mobile;
                $favoritedata[$p]['user_type']=$favoriteList->user_type;
                $favoritedata[$p]['service_id']=$favoriteList->service_id;
                $favoritedata[$p]['gender']=$favoriteList->gender;
                $favoritedata[$p]['specializations']=$favoriteList->specializations;
                $favoritedata[$p]['practicing']=$favoriteList->practicing;
                $favoritedata[$p]['experience']=$favoriteList->experience;
                $favoritedata[$p]['license_number']=$favoriteList->license_number;
                $favoritedata[$p]['bank_details']=$favoriteList->bank_details;
                $favoritedata[$p]['ifsc_code']=$favoriteList->ifsc_code;
                $favoritedata[$p]['city']=$favoriteList->city;
                $favoritedata[$p]['state']=$favoriteList->state;
                $favoritedata[$p]['country']=$favoriteList->country;
                $favoritedata[$p]['pin_code']=$favoriteList->pin_code;
                $favoritedata[$p]['address']=$favoriteList->address;
                $favoritedata[$p]['bio']=$favoriteList->bio;

                //Nursing Image
                $favoritedata[$p]['avatar']='';
                if(!empty($favoriteList->avatar) && file_exists(public_path('img/avatars/'.$favoriteList->avatar)))
                {
                    $favoritedata[$p]['avatar']=url('img/avatars/'.$favoriteList->avatar);
                }
                else
                {
                    $favoritedata[$p]['avatar']=url('img/avatars/default-user-profile.png');
                }

                //Showing Favourite of Nursing Staff
                $favoritedata[$p]['favorites']=0;
                if(isset($checkfavorite) && in_array($favoriteList->id, $checkfavorite))
                {
                    $favoritedata[$p]['favorites']=1;
                }

                }
                $resultArray['status']='1';
                $resultArray['message']=trans('api.favorite_list');
                $resultArray['data']=$favoritedata;
                $resultArray['current_page']=$favoriteLists->currentPage();
                $resultArray['total_page']=$favoriteLists->lastPage();
                return response()->json($resultArray); exit;
            }
            else
            {
                $resultArray['status']=0;
                $resultArray['message']=trans('api.favorite_not_found');
                return response()->json($resultArray); exit;
            }
                             
    }


    public function home(Request $request)
    {    
        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
        //echo '<pre>'; print_r($userid); exit();
        // $city='';

        $validator = Validator::make($request->all(), [
            'lat'=>'required',
            'lng'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            //$access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $lat = isset($request->lat) && !empty($request->lat) ? $request->lat: '';
            $lng = isset($request->lng) && !empty($request->lng) ? $request->lng: '';
            $city = isset($request->city) && !empty($request->city) ? $request->city: '';
            $limit = $request->limit ? $request->limit : 20;
            $page = $request->page && $request->page > 0 ? $request->page : 1;
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
            App::setLocale($lang);

            $radius = 5;
            if(empty($city))
            {
                $query=DB::table('users')
                ->join('userprofiles','userprofiles.user_id','=','users.id')
                ->where('users.user_type',2)
                ->whereNotNull('users.email')->whereNotNull('users.mobile')->whereNotNull('users.service_id')->whereNotNull('users.date_of_birth')->whereNotNull('userprofiles.specializations')->whereNotNull('userprofiles.experience')->whereNotNull('userprofiles.license_number')->whereNotNull('userprofiles.bank_details')->whereNotNull('userprofiles.ifsc_code')
                ->select('users.*', 'userprofiles.specializations', 'userprofiles.practicing', 'userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.city','userprofiles.state','userprofiles.country','userprofiles.pin_code','userprofiles.address','userprofiles.bio', DB::raw("(6371 * acos( cos( radians(" . $lat . ") ) *cos( radians(users.lat) ) *cos( radians(users.lng) - radians(" . $lng . ") ) + sin( radians(" . $lat . ") ) *sin( radians(users.lat) ) ) ) AS distance"))

               /* ->selectRaw("users.*,
                            ( 6371 * acos( cos( radians(" . $lat . ") ) *
                            cos( radians(users.lat) ) *
                            cos( radians(users.lng) - radians(" . $lng . ") ) + 
                            sin( radians(" . $lat . ") ) *
                            sin( radians(users.lat) ) ) ) 
                            AS distance")*/
        
                ->having("distance", "<", $radius);
               
                $servicemapDatas=$query->orderBy("distance")->paginate($limit);
            }

            if(!empty($city))
            {
                $servicemapDatas=DB::table('userprofiles')
                ->join('users','users.id','=','userprofiles.user_id')
                ->where('user_type',2)->where('userprofiles.city',$city)
                //->select('userprofiles.*')
                ->paginate($limit);
            }   
           // echo '<pre>'; print_r($servicemapDatas); exit();

            //favoritedata
            $checkfavorite = array();
            if(!empty($userid)){
            $checkfavorite=DB::table('favorites')->where('user_id',$userid)->pluck('doctor_id')->toArray();
            }

            $nursingInfo=array();
            foreach($servicemapDatas as $p=>$nursinglist)
            {
                $nursingInfo[$p]['name']=$nursinglist->name;
                $nursingInfo[$p]['username']=$nursinglist->username;
                $nursingInfo[$p]['email']=$nursinglist->email;
                $nursingInfo[$p]['mobile']=$nursinglist->mobile;
                $nursingInfo[$p]['user_type']=$nursinglist->user_type;
                $nursingInfo[$p]['service_id']=$nursinglist->service_id;
                $nursingInfo[$p]['gender']=$nursinglist->gender;
                $nursingInfo[$p]['specializations']=$nursinglist->specializations;
                $nursingInfo[$p]['practicing']=$nursinglist->practicing;
                $nursingInfo[$p]['experience']=$nursinglist->experience;
                $nursingInfo[$p]['license_number']=$nursinglist->license_number;
                $nursingInfo[$p]['bank_details']=$nursinglist->bank_details;
                $nursingInfo[$p]['ifsc_code']=$nursinglist->ifsc_code;
                $nursingInfo[$p]['city']=$nursinglist->city;
                $nursingInfo[$p]['state']=$nursinglist->state;
                $nursingInfo[$p]['country']=$nursinglist->country;
                $nursingInfo[$p]['pin_code']=$nursinglist->pin_code;
                $nursingInfo[$p]['address']=$nursinglist->address;
                $nursingInfo[$p]['bio']=$nursinglist->bio;

                //Nursing Image
                $nursingInfo[$p]['avatar']='';
                if(!empty($nursinglist->avatar) && file_exists(public_path('img/avatars/'.$nursinglist->avatar)))
                {
                    $nursingInfo[$p]['avatar']=url('img/avatars/'.$nursinglist->avatar);
                }
                else
                {
                    $nursingInfo[$p]['avatar']=url('img/avatars/default-user-profile.png');
                }

                //Nursing Time Slots (Current)
                $nursingInfo[$p]['time_slot']=getLatestslot($nursinglist->id);

                //Showing Rating of Nursing Staff
                $nursingInfo[$p]['user_id']=$nursinglist->id;
                $nursingInfo[$p]['ratings']=0;
                $avg_stars = DB::table('user_feedbacks')->where('user_feedbacks.doctor_id',$nursinglist->id)->avg('ratings');
                if(!empty($avg_stars))
                {
                    $nursingInfo[$p]['ratings']=number_format($avg_stars,1);
                }

                //Showing Favourite of Nursing Staff
                $nursingInfo[$p]['favorites']=0;
                if(isset($checkfavorite) && in_array($nursinglist->id, $checkfavorite))
                {
                    $nursingInfo[$p]['favorites']=1;
                }

            }

            $serviceMap1=array();
            if(count($servicemapDatas)>0)
            {
                
                $resultArray['status']='1';
                $resultArray['message']=trans('Available Nursing Staff');
                $resultArray['nursinglist']= $nursingInfo;
                $resultArray['current_page']=$servicemapDatas->currentPage();
                $resultArray['total_page']=$servicemapDatas->lastPage();
                return response()->json($resultArray); exit;
            }
            // elseif()
            // {
                 
            // }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('Nursing Not Available');
               return response()->json($resultArray); exit;
            }
    }

    
    public function appointmentBooking(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
            'doctor_id'=>'required',
            'service_id'=>'required',
            'booking_date'=>'required',
            'booking_time'=>'required',
            'total_amount'=>'required',
            'txn_id'=>'required',
            //'lat'=>'required',
            //'lng'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $doctorId = isset($request->doctor_id) && !empty($request->doctor_id) ? $request->doctor_id: '';
            $serviceId = isset($request->service_id) && !empty($request->service_id) ? $request->service_id: '';
            $booking_date = isset($request->booking_date) && !empty($request->booking_date) ? $request->booking_date: '';
            $booking_time = isset($request->booking_time) && !empty($request->booking_time) ? $request->booking_time: '';
            $totalAmount = isset($request->total_amount) && !empty($request->total_amount) ? $request->total_amount: '';

            $txn_id = isset($request->txn_id) && !empty($request->txn_id) ? $request->txn_id: '';
            $lat = isset($request->lat) && !empty($request->lat) ? $request->lat: '';
            $lng = isset($request->lng) && !empty($request->lng) ? $request->lng: '';


            $pateintName = isset($request->patient_name) && !empty($request->patient_name) ? $request->patient_name: '';
            $contactNum = isset($request->contact_num) && !empty($request->contact_num) ? $request->contact_num: '';
            $email = isset($request->email) && !empty($request->email) ? $request->email: '';
            $houseNum = isset($request->house_num) && !empty($request->house_num) ? $request->house_num: '';
            $address = isset($request->address) && !empty($request->address) ? $request->address: '';
            $landmark = isset($request->landmark) && !empty($request->landmark) ? $request->landmark: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
            //App::setLocale($lang);
            
            $chekdata=DB::table('booking_appointments')->whereRaw("(user_id='".$userId."' AND doctor_id='".$doctorId."' AND  booking_date='".$booking_date."' AND  booking_time='".$booking_time."')")->first();
            if(!empty($chekdata))
            { 
                $resultArray['status']='0';
                $resultArray['message']=trans('Booking Slot Not Available');
                return response()->json($resultArray); exit;
            }
              
            $lastid= DB::table('booking_appointments')->insertGetId([
                                            'user_id'=>$userId,
                                            'doctor_id'=>$doctorId,
                                            'service_id'=>$serviceId,
                                            'booking_date'=>date('Y-m-d',strtotime($booking_date)),
                                            'booking_time'=>$booking_time,
                                            'booking_day'=>date('D',strtotime($booking_date)),
                                            'patient_name'=>$pateintName,
                                            'contact_num'=>$contactNum,
                                            'email'=>$email,
                                            'house_num'=>$houseNum,
                                            'address'=>$address,
                                            'landmark'=>$landmark,
                                            'lat'=>$lat,
                                            'lng'=>$lng,
                                            ]);
           // $lastid=DB::table('booking_appointments')->insertGetId($bookdata);

            DB::table('booking_appointment_payments')->insert([
                                            'booking_id'=>$lastid,
                                            'txn_id'=>$txn_id,
                                            'payment_status'=>1,
                                            'total_amount'=>$totalAmount,
                                            'payment_method'=>'Razorpay',
                                            ]);
                 
            $deviceId=DB::table('users')->where('id',$doctorId)->first(); 
            //echo "<pre>"; print_r($deviceId); die();
            $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

            $noti_type='booking';
            $title='Appointment booked';
            $message='Your appointment booked successfully';      
            
            $this->postpushnotification($device_id,$title,$message,$noti_type);

            $resultArray['status']='1';
            $resultArray['message']=trans('Appointment booked successfully');
            return response()->json($resultArray); exit;   
    }

                
    /* Get All Care Seeker Bookings List  */
    public function careSeekerBookings(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            'user_id'=>'required',
        ]);

            if($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }

        // printf($todayDate);die;
        $predate=date('Y-m-d');
        $update=date('Y-m-d');
        //print_r($predate);die;

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $type = isset($request->type) && !empty($request->type) ? $request->type: '';
        $limit = $request->limit ? $request->limit : 20;
        $page = $request->page && $request->page > 0 ? $request->page : 1;
        $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
        App::setLocale($lang);

        //Get Data of user
        $bookings=DB::table('booking_appointments')->where('users.id',$userId)
        ->join('users','users.id','=','booking_appointments.user_id')
        ->join('services','services.id','=','booking_appointments.service_id')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->leftjoin('users AS A', 'A.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS B', 'B.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS C', 'C.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS D', 'D.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS E', 'E.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('userprofiles','userprofiles.user_id','=','booking_appointments.doctor_id')
        ->select('booking_appointments.*','A.name as user_id','B.name as doctor_id','C.avatar as avatar','D.mobile as mobile','E.id as myid','services.service_name','userprofiles.address','booking_appointment_payments.booking_id','booking_appointment_payments.total_amount','booking_appointment_payments.currency','booking_appointment_payments.txn_id')->paginate($limit);
        
        //echo "<pre>";print_r($bookings);exit;
        if(count($bookings)<1)
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('No Appointment Found..');
            return response()->json($resultArray); exit; 
        }

        $userBooking=array();
        //echo "<pre>";print_r($type);exit;

        foreach($bookings as $p =>$bookingList)
        {
            $mydate=strtotime($bookingList->booking_date); 
            if(($mydate <strtotime($predate)) && $type=='previous')
            {    
                //echo "hi";
                $allBookings['careseeker_name']=isset($bookingList->user_id)?$bookingList->user_id:'';  
                $allBookings['nursing_name']=isset($bookingList->doctor_id)?$bookingList->doctor_id:'';
                //$allBookings['avatar']=isset($bookingList->avatar)?$bookingList->avatar:'';

                //Nursing Image
                $allBookings['avatar']='';
                if(!empty($bookingList->avatar) && file_exists(public_path('img/avatars/'.$bookingList->avatar)))
                {
                    $allBookings['avatar']=url('img/avatars/'.$bookingList->avatar);
                }
                else
                {
                    $allBookings['avatar']=url('img/avatars/default-user-profile.png');
                }

                $allBookings['mobile']=isset($bookingList->mobile)?$bookingList->mobile:'';
                $allBookings['address']=isset($bookingList->address)?$bookingList->address:'';
                $allBookings['services_name']=isset($bookingList->service_name)?$bookingList->service_name:'';
                $allBookings['booking_day']=isset($bookingList->booking_day)?$bookingList->booking_day:'';
                $allBookings['booking_date']=isset($bookingList->booking_date)?$bookingList->booking_date:'';
                $allBookings['booking_time']=isset($bookingList->booking_time)?$bookingList->booking_time:'';
                //$allBookings['booking_status']=isset($bookingList->status)?$bookingList->status:'';

                if($bookingList->status =='Confirm')
                    $allBookings['booking_status']='Accepted';
                elseif($bookingList->status =='Reject Request')
                    $allBookings['booking_status']='Reject Request submitted';
                elseif($bookingList->status =='Pending')
                    $allBookings['booking_status']='Rejected';
                elseif($bookingList->status =='Reject')
                    $allBookings['booking_status']='Rejected';

                $allBookings['final_status']=isset($bookingList->booking_status)?$bookingList->booking_status:'';
                $allBookings['booking_id']=isset($bookingList->booking_id)?$bookingList->booking_id:'';
                $allBookings['doctor_id']=isset($bookingList->myid)?$bookingList->myid:'';
                $allBookings['total_amount']=isset($bookingList->total_amount)?$bookingList->total_amount:'';

                $allBookings['message']=isset($bookingList->message)?$bookingList->message:'';
                array_push($userBooking,$allBookings); 
            }
            
            elseif($mydate >= strtotime($update) &&  $type=='upcoming')
            {
                $allBookings['careseeker_name']=isset($bookingList->user_id)?$bookingList->user_id:'';  
                $allBookings['nursing_name']=isset($bookingList->doctor_id)?$bookingList->doctor_id:'';
                //$allBookings['avatar']=isset($bookingList->avatar)?$bookingList->avatar:'';

                //Nursing Image
                $allBookings['avatar']='';
                if(!empty($bookingList->avatar) && file_exists(public_path('img/avatars/'.$bookingList->avatar)))
                {
                    $allBookings['avatar']=url('img/avatars/'.$bookingList->avatar);
                }
                else
                {
                    $allBookings['avatar']=url('img/avatars/default-user-profile.png');
                }    

                $allBookings['mobile']=isset($bookingList->mobile)?$bookingList->mobile:'';
                $allBookings['address']=isset($bookingList->address)?$bookingList->address:'';
                $allBookings['services_name']=isset($bookingList->service_name)?$bookingList->service_name:'';
                $allBookings['booking_day']=isset($bookingList->booking_day)?$bookingList->booking_day:'';
                $allBookings['booking_date']=isset($bookingList->booking_date)?$bookingList->booking_date:'';
                $allBookings['booking_time']=isset($bookingList->booking_time)?$bookingList->booking_time:'';
                //$allBookings['booking_status']=isset($bookingList->status)?$bookingList->status:'';

                if($bookingList->status =='Confirm')
                    $allBookings['booking_status']='Accepted';
                elseif($bookingList->status =='Reject Request')
                    $allBookings['booking_status']='Reject Request submitted';
                elseif($bookingList->status =='Pending')
                    $allBookings['booking_status']='Pending';
                elseif($bookingList->status =='Reject')
                    $allBookings['booking_status']='Rejected';

                $allBookings['final_status']=isset($bookingList->booking_status)?$bookingList->booking_status:'';
                $allBookings['booking_id']=isset($bookingList->booking_id)?$bookingList->booking_id:'';
                $allBookings['doctor_id']=isset($bookingList->myid)?$bookingList->myid:'';
                $allBookings['total_amount']=isset($bookingList->total_amount)?$bookingList->total_amount:'';
                
                $allBookings['message']=isset($bookingList->message)?$bookingList->message:'';
                array_push($userBooking,$allBookings); 
            }
       }
        $resultArray['status']=1;
        $resultArray['data']= $userBooking;
        $resultArray['message']=trans('All Appointments List');
        $resultArray['current_page']=$bookings->currentPage();
        $resultArray['total_page']=$bookings->lastPage();
        return response()->json($resultArray); exit;
        
    }

    //Cancel Booking By Care Seeker
    public function careSeekerBookingCancel(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
            'booking_id'=>'required',
            'cancel_reason'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
           
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $bookingId = isset($request->booking_id) && !empty($request->booking_id) ? $request->booking_id: '';
            $cancelReason = isset($request->cancel_reason) && !empty($request->cancel_reason) ? $request->cancel_reason: '';
            //print_r($bookingId);die;
           
            $todaydate = date('Y-m-d H:i:s');
            //print_r($todaydate);die;

            $checkall=DB::table('booking_appointments')->where('user_id',$userId)->where('id',$bookingId)->whereIn('status', ['Pending', 'Confirm'])->first();
            //print_r($checkall);exit;

            if(!empty($checkall))
            {                   
                DB::table('booking_appointments')->where('id', $bookingId)->update(['status' => 'Reject Request','user_type' => 3, 'cancellation_request_time' => $todaydate, 'cancel_reason' => $cancelReason]);

                $deviceId=DB::table('users')->where('id',$request->user_id)->first(); 
                //echo "<pre>"; print_r($deviceId); die();
                $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

                $noti_type='';
                $title='Appointment Cancellation Request';
                $message='Your appointment cancellation request submitted.';      
                
                $this->postpushnotification($device_id,$title,$message,$noti_type);    

                $resultArray['status']='1';
                $resultArray['message']=trans('Booking cancel successfully');
                return response()->json($resultArray); exit;                    
            }
                
            else
            {
                $resultArray['status']=0;
                $resultArray['message']=trans('Booking not found');
                return response()->json($resultArray); exit;
            }   
    }

    /* Get All Nursing Professional Bookings List  */
    public function nursingStaffBookings(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            'user_id'=>'required',
        ]);

            if($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }

        // printf($todayDate);die;
        $predate=date('Y-m-d');
        $update=date('Y-m-d');
        //print_r($predate);die;

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $type = isset($request->type) && !empty($request->type) ? $request->type: '';
        $limit = $request->limit ? $request->limit : 20;
        $page = $request->page && $request->page > 0 ? $request->page : 1;
        $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
        App::setLocale($lang);

        //Get Data of user
        $bookings=DB::table('booking_appointments')->where('users.id',$userId)
        ->join('users','users.id','=','booking_appointments.doctor_id')
        ->join('services','services.id','=','booking_appointments.service_id')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->leftjoin('users AS A', 'A.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS E', 'E.id', '=', 'booking_appointments.doctor_id')
        ->leftjoin('users AS B', 'B.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS C', 'C.id', '=', 'booking_appointments.user_id')
        ->leftjoin('users AS D', 'D.id', '=', 'booking_appointments.user_id')
        ->leftjoin('userprofiles','userprofiles.user_id','=','booking_appointments.user_id')
        ->select('booking_appointments.*','A.name as doctor_id','B.name as user_id','C.avatar as avatar','D.mobile as mobile','E.id as myid','services.service_name','booking_appointment_payments.booking_id','booking_appointment_payments.total_amount','booking_appointment_payments.currency','booking_appointment_payments.txn_id')->paginate($limit);
        
        //echo "<pre>";print_r($bookings);exit;
        if(count($bookings)<1)
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('No Appointment Found..');
            return response()->json($resultArray); exit; 
        }

        $userBooking=array();
        //echo "<pre>";print_r($type);exit;

        foreach($bookings as $p =>$bookingList)
        {
            $mydate=strtotime($bookingList->booking_date); 
            // if($bookingList->status=='Pending' && $type=='pending')
            if(($mydate <strtotime($predate)) && $type=='previous')
            {    
                //echo "hi";
                $allBookings['name']=isset($bookingList->doctor_id)?$bookingList->doctor_id:'';  
                $allBookings['user_name']=isset($bookingList->user_id)?$bookingList->user_id:'';
                //$allBookings['avatar']=isset($bookingList->avatar)?$bookingList->avatar:'';

                //User Image
                $allBookings['avatar']='';
                if(!empty($bookingList->avatar) && file_exists(public_path('img/avatars/'.$bookingList->avatar)))
                {
                    $allBookings['avatar']=url('img/avatars/'.$bookingList->avatar);
                }
                else
                {
                    $allBookings['avatar']=url('img/avatars/default-user-profile.png');
                }

                $allBookings['mobile']=isset($bookingList->mobile)?$bookingList->mobile:'';
                $allBookings['address']=isset($bookingList->address)?$bookingList->address:'';
                $allBookings['landmark']=isset($bookingList->landmark)?$bookingList->landmark:'';
                $allBookings['services_name']=isset($bookingList->service_name)?$bookingList->service_name:'';
                $allBookings['booking_day']=isset($bookingList->booking_day)?$bookingList->booking_day:'';
                $allBookings['booking_date']=isset($bookingList->booking_date)?$bookingList->booking_date:'';
                $allBookings['booking_time']=isset($bookingList->booking_time)?$bookingList->booking_time:'';

                if($bookingList->status =='Confirm')
                    $allBookings['booking_status']='Accepted';
                elseif($bookingList->status =='Reject Request')
                    $allBookings['booking_status']='Reject Request submitted';
                elseif($bookingList->status =='Pending')
                    $allBookings['booking_status']='Pending';
                elseif($bookingList->status =='Reject')
                    $allBookings['booking_status']='Rejected';

                $allBookings['final_status']=isset($bookingList->booking_status)?$bookingList->booking_status:'';
                $allBookings['booking_id']=isset($bookingList->booking_id)?$bookingList->booking_id:'';
                $allBookings['doctor_id']=isset($bookingList->myid)?$bookingList->myid:'';
                $allBookings['total_amount']=isset($bookingList->total_amount)?$bookingList->total_amount:'';

                $allBookings['message']=isset($bookingList->message)?$bookingList->message:'';
                array_push($userBooking,$allBookings); 
            }
            
            // elseif($bookingList->status=='Confirm' &&  $type=='confirm')
            elseif($mydate >= strtotime($update) &&  $type=='upcoming')
            {
                $allBookings['name']=isset($bookingList->user_id)?$bookingList->user_id:'';  
                $allBookings['user_name']=isset($bookingList->user_id)?$bookingList->user_id:'';
                //$allBookings['avatar']=isset($bookingList->avatar)?$bookingList->avatar:'';

                //Nursing Image
                $allBookings['avatar']='';
                if(!empty($bookingList->avatar) && file_exists(public_path('img/avatars/'.$bookingList->avatar)))
                {
                    $allBookings['avatar']=url('img/avatars/'.$bookingList->avatar);
                }
                else
                {
                    $allBookings['avatar']=url('img/avatars/default-user-profile.png');
                }

                $allBookings['mobile']=isset($bookingList->mobile)?$bookingList->mobile:'';
                $allBookings['address']=isset($bookingList->address)?$bookingList->address:'';
                $allBookings['landmark']=isset($bookingList->landmark)?$bookingList->landmark:'';
                $allBookings['services_name']=isset($bookingList->service_name)?$bookingList->service_name:'';
                $allBookings['booking_day']=isset($bookingList->booking_day)?$bookingList->booking_day:'';
                $allBookings['booking_date']=isset($bookingList->booking_date)?$bookingList->booking_date:'';
                $allBookings['booking_time']=isset($bookingList->booking_time)?$bookingList->booking_time:'';

                if($bookingList->status =='Confirm')
                    $allBookings['booking_status']='Accepted';
                elseif($bookingList->status =='Reject Request')
                    $allBookings['booking_status']='Reject Request submitted';
                elseif($bookingList->status =='Pending')
                    $allBookings['booking_status']='Pending';
                elseif($bookingList->status =='Reject')
                    $allBookings['booking_status']='Rejected';

                //$allBookings['booking_status']=isset($bookingList->status)?$bookingList->status:'';
                $allBookings['final_status']=isset($bookingList->booking_status)?$bookingList->booking_status:'';
                $allBookings['booking_id']=isset($bookingList->booking_id)?$bookingList->booking_id:'';
                 $allBookings['doctor_id']=isset($bookingList->myid)?$bookingList->myid:'';
                $allBookings['total_amount']=isset($bookingList->total_amount)?$bookingList->total_amount:'';
                
                $allBookings['message']=isset($bookingList->message)?$bookingList->message:'';
                array_push($userBooking,$allBookings); 
            }

       }
        $resultArray['status']=1;
        $resultArray['data']= $userBooking;
        $resultArray['message']=trans('All Appointments List');
        $resultArray['current_page']=$bookings->currentPage();
        $resultArray['total_page']=$bookings->lastPage();
        return response()->json($resultArray); exit;
        
    }

    /* Cancel Booking by Nursing Staff */
    public function nursingBookingAction(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
            'booking_id'=>'required',
            //'cancel_reason'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
           
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $bookingId = isset($request->booking_id) && !empty($request->booking_id) ? $request->booking_id: '';
            $cancelReason = isset($request->cancel_reason) && !empty($request->cancel_reason) ? $request->cancel_reason: '';
            $type = isset($request->type) && !empty($request->type) ? $request->type: '';
            //print_r($userId);die;
           
            $todaydate = date('Y-m-d H:i:s');
            //print_r($todaydate);die;

            $checkall=DB::table('booking_appointments')->where('doctor_id',$userId)->where('id',$bookingId)->whereIn('status', ['Pending', 'Confirm'])->first();
           // print_r($checkall);exit;

            if(!empty($checkall) && $type=='cancel')
            {                   
                DB::table('booking_appointments')->where('id', $bookingId)->update(['status' => 'Reject Request','user_type' => 2, 'cancellation_request_time' => $todaydate, 'cancel_reason' => $cancelReason]);
                
                $deviceId=DB::table('users')->where('id',$checkall->user_id)->first(); 
                //echo "<pre>"; print_r($deviceId); die();
                $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

                $noti_type='';
                $title='Appointment Cancellation Request';
                $message='Your appointment cancellation request submitted.';      
                
                $this->postpushnotification($device_id,$title,$message,$noti_type);     

                $resultArray['status']='1';
                $resultArray['message']=trans('Booking cancel successfully');
                return response()->json($resultArray); exit;                    
            }

            elseif(!empty($checkall) && $type=='accept')
            {
                DB::table('booking_appointments')->where('id', $bookingId)->update(['status' => 'Confirm']);
                
                $deviceId=DB::table('users')->where('id',$checkall->user_id)->first(); 
                //echo "<pre>"; print_r($deviceId); die();
                $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

                $noti_type='';
                $title='Appointment Accepted';
                $message='Your appointment accepted successfully by nursing staff.';      
                
                $this->postpushnotification($device_id,$title,$message,$noti_type);     

                $resultArray['status']='1';
                $resultArray['message']=trans('Booking Accepted successfully');
                return response()->json($resultArray); exit;  
            }

            elseif(!empty($checkall) && $type=='complete' && $checkall->status == 'Confirm' && $checkall->booking_date < $todaydate)
            {
                $booking_info=DB::table('booking_appointments')->where('booking_appointments.id', $bookingId)
                ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
                ->first();
                //print_r($booking_info); die();
                // showing Commission fee from Commission table         
                $service_amount= DB::table('service_fees')->get();

                $amount=$booking_info->total_amount;
                $commission=$service_amount[0]->service_fee;
                $earning_amount= ($amount/100) * $commission;

                DB::table('booking_appointments')->where('id', $bookingId)->update(['booking_appointments.booking_status' => 'Complete','booking_appointments.commission_charge' => isset($service_amount[0]->service_fee)?$service_amount[0]->service_fee:'', 'booking_appointments.commission_amount' => isset($earning_amount)?$earning_amount:'']);
                
                $deviceId=DB::table('users')->where('id',$checkall->user_id)->first(); 
                //echo "<pre>"; print_r($deviceId); die();
                $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

                $noti_type='';
                $title='Appointment Completeed';
                $message='Your appointment Completed successfully.';      
                
                $this->postpushnotification($device_id,$title,$message,$noti_type);     

                $resultArray['status']='1';
                $resultArray['message']=trans('Booking Completed successfully');
                return response()->json($resultArray); exit;  
            }
                
            else
            {
                $resultArray['status']=0;
                $resultArray['message']=trans('Booking not found');
                return response()->json($resultArray); exit;
            }   
    }

    
    // Average Review for Nursing staff //

    public function feedbackAvg(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }  
        
        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);

        
        $feedbacklist=DB::table('user_feedbacks')->where('doctor_id',$userid)->get();
        // echo'<pre>';print_r($feedbacklist);exit;

        $sum = 0;
        foreach($feedbacklist as $value){
            $sum += $value->ratings;
        }
        if(count($feedbacklist)!=0)
        {
            $avg = $sum / count($feedbacklist);
        }
        else
        {
            $avg = $sum;
        }
        //echo'<pre>';print_r($avg);exit;

        $totalfeedback=DB::table('user_feedbacks')->where('doctor_id',$userid)->count();
        //echo'<pre>';print_r($totalfeedback);exit;

        /* Show total bookings */
        $totalbooking=DB::table('booking_appointments')->where('doctor_id',$userid)->count();

        /* Show today bookings */
        $todaydate = date('Y-m-d');
        $todaybooking=DB::table('booking_appointments')->where('doctor_id',$userid)->where('booking_date',$todaydate)->count();

        /* Show Total Revenew */ 
        $revenew=DB::table('booking_appointments')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->where('booking_appointments.doctor_id',$userid)
        ->get();
        //print_r($revenew); die();
        $toatl_income = 0;
        //$toatl_income = $toatl_income + ($revenew[0]->commission_amount);
        foreach($revenew as $revenew_value){
            $toatl_income += $revenew_value->commission_amount;
        }
        if(count($revenew)!=0)
        {
            $income_data = $toatl_income;
        }
        else
        {
            $income_data = $toatl_income;
        } 

        $resultArray['status']=1;
        $resultArray['message']=trans('nursing staff basic details for dashboard');
        //$resultArray['data']=$feedbacklist;
        $resultArray['total_feedback']=$totalfeedback;
        $resultArray['average']=$avg;
        $resultArray['total_appointment']=$totalbooking;
        $resultArray['today_appointment']=$todaybooking;
        $resultArray['total_income']=$income_data;
        echo json_encode($resultArray); exit;  
    }


    public function giveFeedback(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
            'doctor_id'=>'required',
            'ratings'=>'required',
            //'feedback'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $doctorId = isset($request->doctor_id) && !empty($request->doctor_id) ? $request->doctor_id: '';
        $ratings = isset($request->ratings) && !empty($request->ratings) ? $request->ratings: '';
        $feedback = isset($request->feedback) && !empty($request->feedback) ? $request->feedback: '';

        $data = DB::table('booking_appointments')->where('user_id',$userId)
        ->where('doctor_id',$doctorId)->first();

        if(!empty($data))
        {
            DB::table('user_feedbacks')->insert([
            'user_id'=>$userId,'doctor_id'=>$doctorId,'ratings'=>$ratings,'feedback'=>$feedback,'status'=>1]);
           
            $resultArray['status']='1';
            $resultArray['message']=trans('your feedback successfully updated');
            return response()->json($resultArray); exit; 
        }
        else
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('You have not used this service, you can not leave feedback.');
            return response()->json($resultArray); exit;
        }    
    }

    /* Showing Transaction History */
    public function showTransaction(Request $request)
    {
        $validator = Validator::make($request->all(), [
           // 'user_id' => 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        } 

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $doctorId = isset($request->doctor_id) && !empty($request->doctor_id) ? $request->doctor_id: '';
        $limit = $request->limit ? $request->limit : 20;
        $page = $request->page && $request->page > 0 ? $request->page : 1;

        $query=DB::table('booking_appointments')
        ->leftjoin('users', 'users.id', '=', 'booking_appointments.user_id')
        ->leftjoin('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id');
        if(!empty($userId))
            {
                $query->where('booking_appointments.user_id', $userId);
            }
        else
            {
                $query->where('booking_appointments.doctor_id', $doctorId)->where('booking_appointments.commission_amount','>', 0)->where('booking_appointments.booking_status','Complete');
            }
        
       $NursingTransaction= $query->select('booking_appointments.*','users.name','booking_appointment_payments.txn_id','booking_appointment_payments.booking_id','booking_appointment_payments.currency','booking_appointment_payments.total_amount','booking_appointment_payments.payment_method','booking_appointment_payments.payment_status')
        ->orderBy('id','desc')
        ->paginate($limit);
        //print_r($NursingTransaction); die();
        

        $nursingtransaction=array();
        foreach($NursingTransaction as $p =>$TransactionList)
        {
            if(!empty($doctorId))
            {
                $userinfo=DB::table('users')->where('id',$TransactionList->user_id)->first();
                $user_message='booking payment INR'. ' '.$TransactionList->commission_amount.' '. 'received successfully'; 
            }
            else
            {
                $userinfo= DB::table('users')->where('id',$TransactionList->doctor_id)->first();
                $user_message='you paid INR'. ' '.$TransactionList->total_amount.' '. ' successfully';
            }

            $nursingtransaction[$p]['user_name']=isset($userinfo->username)?$userinfo->username:'';
            $nursingtransaction[$p]['avatar']='';
                if(!empty($userinfo->avatar) && file_exists(public_path('img/avatars/'.$userinfo->avatar)))
                {
                    $nursingtransaction[$p]['avatar']=url('img/avatars/'.$userinfo->avatar);
                }
                else
                {
                    $nursingtransaction[$p]['avatar']=url('img/avatars/default-user-profile.png');
                }

            $nursingtransaction[$p]['message']=isset($user_message)?$user_message:'';      

            $nursingtransaction[$p]['booking_id']=isset($TransactionList->booking_id)?$TransactionList->booking_id:'';
            $nursingtransaction[$p]['txn_id']=isset($TransactionList->txn_id)?$TransactionList->txn_id:'';
            $nursingtransaction[$p]['total_amount']=isset($TransactionList->total_amount)?$TransactionList->total_amount:'';

            $nursingtransaction[$p]['payment_method']=isset($TransactionList->payment_method)?$TransactionList->payment_method:'';
            $nursingtransaction[$p]['payment_status']=isset($TransactionList->payment_status)?$TransactionList->payment_status:'';
            $nursingtransaction[$p]['created_at']=isset($TransactionList->created_at)?$TransactionList->created_at:'';

            $nursingtransaction[$p]['cancellation_charge']=isset($TransactionList->cancellation_charge)?$TransactionList->cancellation_charge:'';
            $nursingtransaction[$p]['commission_charge']=isset($TransactionList->commission_charge)?$TransactionList->commission_charge:'';
            $nursingtransaction[$p]['cancellation_amount']=isset($TransactionList->cancellation_amount)?$TransactionList->cancellation_amount:'';
            $nursingtransaction[$p]['commission_amount']=isset($TransactionList->commission_amount)?$TransactionList->commission_amount:'';
        }

        /* Show Total Revenew */ 
        $revenew=DB::table('booking_appointments')
        ->join('booking_appointment_payments','booking_appointment_payments.booking_id','=','booking_appointments.id')
        ->where('booking_appointments.doctor_id',$doctorId)
        ->get();
        //print_r($revenew); die();
        $toatl_income = 0;
        //$toatl_income = $toatl_income + ($revenew[0]->commission_amount);
        foreach($revenew as $revenew_value){
            $toatl_income += $revenew_value->commission_amount;
        }
        if(count($revenew)!=0)
        {
            $income_data = $toatl_income;
        }
        else
        {
            $income_data = $toatl_income;
        } 

        $resultArray['status']=1;
        $resultArray['data']= $nursingtransaction;
        $resultArray['message']=trans('All Transaction List');
        $resultArray['total_income']=$income_data;
        $resultArray['current_page']=$NursingTransaction->currentPage();
        $resultArray['total_page']=$NursingTransaction->lastPage();
        return response()->json($resultArray); exit;
    }
}   