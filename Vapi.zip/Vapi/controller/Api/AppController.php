<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB,Mail;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Pages;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Plan;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
use App\Notifications\Frontend\Auth\UserNeedsConfirmation;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class AppController extends APIController
{
    
        public function pages(Request $request)
        {
            $pageType = isset($request->page_type) && !empty($request->page_type) ? $request->page_type : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;

            App::setLocale($lang);

            $validator = Validator::make($request->all(), [
            'page_type' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $pageSlug=DB::table('pages')->where('page_slug',$pageType)->select('title','description')->first();
            if(!empty($pageSlug))
            {
                $dataArray['title']= $pageSlug->title;
                $dataArray['description']= $pageSlug->description;
                $resultArray['status']='1';
                $resultArray['message']=trans('api.page_result_successfully');
                $resultArray['data']=$dataArray;
                echo json_encode($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.data_not_found');
                echo json_encode($resultArray); exit;
            }
        }


           

}   