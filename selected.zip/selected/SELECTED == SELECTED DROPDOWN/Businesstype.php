<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Businesstype extends Model
{
     use SoftDeletes;
    
    //use HasFactory;

    protected $table = 'business_types';
    
    protected $fillable = [
        'business_name',
        'business_image',
        'length',
        'service_type'
    ];

    
   

}
