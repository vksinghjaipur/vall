@extends('backend.layouts.app')

@section('title', __('Payment Management') . ' | ' . __('labels.backend.access.blogs.edit'))

@section('breadcrumb-links')
    @include('backend.business.includes.breadcrumb-links')
@endsection

@section('content')
<form method="post" action="{{route('admin.business.update',$business->id)}}" enctype="multipart/form-data">
  @csrf
    <div class="card">
        @include('backend.business.editform')
        @include('backend.components.footer-buttons', [ 'cancelRoute' => 'admin.business.show', 'id' => $business->id ])
    </div><!--card-->
</form>
@endsection