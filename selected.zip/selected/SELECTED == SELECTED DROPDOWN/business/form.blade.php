<div class="card-body">
    <div class="row">
        <div class="col-sm-5">
            <h4 class="card-title mb-0">
                {{ __('Business Management') }}
                <small class="text-muted">{{ (isset($getpack)) ? __('Edit Plan') : __('Business Type create') }}</small>
            </h4>
        </div>
        <!--col-->
    </div>
    <!--row-->

    <hr>

    <div class="row mt-4 mb-4">
        <div class="col">
            <!-------form-group------>
            <div class="form-group row">
                {{ Form::label('name', trans('Business Type Name'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                    {{ Form::text('name', null, ['class' => 'form-control', 'placeholder' => trans('Business Type name'), 'required' => 'required']) }}
                </div>
            </div>
            <!-----------------form-group------------------->


            <!--------V Length Start------------>
            <div class="form-group row">
                {{ Form::label('length', trans('Length'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                <div class="col-md-10">
                    <select class="form-control" name="length" style="width: 70%; margin-left:-13px" required>
                        <option>Select Length</option>
                        <option value="long">Long</option>
                        <option value="medium">Medium</option>
                        <option value="short">Short</option>
                    </select>
                </div>
                </div>
            </div>
            <!-------V Length End---------------->

            <!-------V Service Type Start-------->
            <div class="form-group row">
                {{ Form::label('service_type', trans('Service Type'), ['class' => 'col-md-2 from-control-label required']) }}
                <div class="col-md-10">
                <div class="col-md-10">
                    <select class="form-control" name="service_type" style="width: 70%; margin-left: -13px" required>
                        <option>Select Service Type</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                </div>
            </div>
            <!---------V Service Type End---------->

            <!-------form-group Business Image Start-------->
            <div class="form-group row">
                {{ Form::label('business_image', trans('Business Image'), ['class' => 'col-md-2 from-control-label required'])}}
                @if(!empty($business->business_image))
                    <div class="col-lg-1">
                        <img src="{{ asset('/img/businessimage/'.$business->business_image) }}" height="80" width="80">
                    </div>
                    <div class="col-lg-5">
                        {{ Form::file('business_image', ['id' => 'business_image']) }}
                    </div>
                @else
                    <div class="col-lg-5">
                        {{ Form::file('business_image', ['id' => 'business_image']) }}
                    </div>
                @endif
            </div>
            <!----------form-group Business image end------->

            
            <div class="form-group row">
                {{ Form::label('status', trans('validation.attributes.backend.access.faqs.status'), ['class' => 'col-md-2 from-control-label required']) }}

                @php
                $status = isset($scooter) ? '' : 'checked'
                @endphp
                
                <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" {{ (isset($scooter->status) && $scooter->status === 1) ? "checked" : $status }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div>
                <!--col-->
            </div>
            <!--form-group-->
        </div>
        <!--col-->
    </div>
    <!--row-->
</div>
<!--card-body-->

@section('pagescript')
<script type="text/javascript">
    FTX.Utils.documentReady(function() {
        FTX.Blogs.edit.init("{{ config('locale.languages.' . app()->getLocale())[1] }}");
    });
</script>
@stop