@extends('backend.layouts.app')

@section('title', __('Business management') . ' | ' . __('Business create'))

@section('breadcrumb-links')
    @include('backend.business.includes.breadcrumb-links')
@endsection

@section('content')
    {{ Form::open(['route' => 'admin.business.store', 'class' => 'form-horizontal', 'role' => 'form', 'method' => 'post', 'id' => 'create-permission', 'files' => true]) }}

    <div class="card">
        @include('backend.business.form')
        @include('backend.components.footer-buttons', [ 'cancelRoute' => 'admin.business.show' ])
    </div><!--card-->
    {{ Form::close() }}
@endsection