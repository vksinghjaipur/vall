<?php

namespace App\Http\Controllers\Backend\Business;

use App\Http\Controllers\Controller;
use App\Http\Responses\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\Scooter\Scooter;
use App\Models\Scooter\Package;
use App\Models\Scooter\Plan;
use App\Models\Scooter\DropPoint;
use App\Models\BlogCategory;
use App\Models\BlogTag;
use DB;
class BusinessController extends Controller
{

    public function index(Request $request)
    {
        $business = DB::table('business_types')->get();
        //dd($business);
        // echo '<pre>'; print_r($scooters);exit;
        return view('backend.business.index', compact('business'));
    }

    /**
     * @param \App\Http\Requests\Backend\Blogs\ManageBlogsRequest $request
     *
     * @return ViewResponse
     */
    public function create()
    {
        return View('backend.business.create');
    }

    /**
     * @param \App\Http\Requests\Backend\Blogs\StoreBlogsRequest $request
     *
     * @return \App\Http\Responses\RedirectResponse
     */
    public function store(Request $request)
    {  
       //echo '<pre>'; print_r($request->all());exit;

        $business_name = $request->name;
        $business_image = $request->business_image;
        $length = $request->length;
        $service_type = $request->service_type;
        $business_status = $request->status;
        $values = array('business_name' => $business_name, 'business_image' => $business_image,'length' => $length,'service_type' => $service_type,'status' => $business_status);
        
        if (isset($values['business_image']) && ! empty($values['business_image'])) {
            $avatar = $values['business_image'];
            $fileName = time().$avatar->getClientOriginalName();
            $destinationPath = public_path('/img/businessimage/');
            $avatar->move($destinationPath, $fileName);
            $values = array_merge($values, ['business_image' => $fileName]);
        }

        DB::table('business_types')->insert($values);
       
       return new RedirectResponse(route('admin.business.show'), ['flash_success' => __('The Business type was successfully created.')]);
    }



        
    

    /**
     * @param \App\Models\Blog $blog
     * @param \App\Http\Requests\Backend\Blogs\ManageBlogsRequest $request
     *
     * @return \App\Http\Responses\Backend\Blog\EditResponse
     */
    public function edit($id=null)
    {
        $business= DB::table('business_types')->where('id',$id)->first();
        return view('backend.business.edit', compact('business'));
    }

    /**
     * @param \App\Models\Blogs\Blog $blog
     * @param \App\Http\Requests\Backend\Blogs\UpdateBlogsRequest $request
     *
     * @return \App\Http\Responses\RedirectResponse
     */
    public function update(Request $request ,$id=null)
    {
   // echo '<pre>'; print_r($request->all());exit;
        $businesstype= array();
        $businesstype['business_name']=$request->name;
        $businesstype['business_image']=$request->business_image;
        $businesstype['length']=$request->length;
        $businesstype['service_type']=$request->service_type;
        $businesstype['status']=$request->status;

       
        if(!empty($businesstype['business_image'])){
        $businesstype['business_image']=$businesstype['business_image'];
        $avatar = $businesstype['business_image'];
        $fileName = time().$avatar->getClientOriginalName();

        $destinationPath = public_path('/img/businessimage/');
        $avatar->move($destinationPath, $fileName);
        $businesstype = array_merge($businesstype, ['business_image' => $fileName]);
        
        }else{
            unset($businesstype['business_image']);
        }  
        
        //Businesstype::where('id',$id)->update($businesstype);

        DB::table('business_types')->where('id',$id)->update($businesstype);

        return new RedirectResponse(route('admin.business.show'), ['flash_success' => __('The Business type was successfully updated.')]);
    }

    /**
     * @param \App\Models\Blog $blog
     * @param \App\Http\Requests\Backend\Blogs\ManageBlogsRequest $request
     *
     * @return \App\Http\Responses\RedirectResponse
     */
    public function businessDelete($id=null)
    {
        DB::table('business_types')->where('id',$id)->delete();
        return new RedirectResponse(route('admin.business.show'), ['flash_success' => __('The Business was successfully deleted.')]);
    }

}
