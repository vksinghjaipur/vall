@extends('frontend.layouts.app')
@section('title', app_name() . ' | ' . __('navs.frontend.dashboard') )
@section('content')

<div class="wrapper">
  <div class="content-wrapper">
      
    	 <section class="content">
        <div class="content-header">
          
          <div class="animated fadeIn">
      <div class="container-fluid">
     <form method="POST" action="{{url('teacher/myactivities/add-activity')}}" accept-charset="UTF-8" class="form-horizontal" role="form" id="create-permission" enctype="multipart/form-data"> {{csrf_field()}}
    
    <div class="card">
      <div class="card-body">
        <div class="teacher_header">
            <div class="row align-items-center">
                <div class="col-sm-5">
                    <h4 class="card-title mb-0">
                        All Activities
                        <small class="text-muted">Create New Activity</small>
                    </h4>
                </div><!--col-->
                <div class="col-sm-7 text-right">
                    <h4 class="card-title mb-0">
                        <a class="btn btn-info btn-rounded" href="{{url('teacher/myactivities')}}"> View All Activities</a>
                    </h4>
                </div><!--col-->
            </div><!--row-->
        </div>
    <hr>

    <div class="create_form mt-4 mb-4">
           <div class="form-group row mb-0">
                {{ Form::label('activity_name', trans('validation.attributes.backend.access.activities.activity_name'), ['class' => 'col-md-2 from-control-label required']) }}
                
                <div class="col-md-10">
                    {{ Form::text('activity_name', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.activities.activity_name'), 'required' => 'required']) }}
                </div><!--col-->
            </div><!--form-group-->

            <div class="form-group row mb-0">
                {{ Form::label('activity_ability', trans('validation.attributes.backend.access.activities.activity_ability'), ['class' => 'col-md-2 from-control-label required']) }}
                
                <div class="col-md-10">
                    {{ Form::text('activity_ability', null, ['class' => 'form-control', 'placeholder' => trans('validation.attributes.backend.access.activities.activity_ability'),]) }}
                </div><!--col-->
            </div><!--form-group-->

            <!--Dropdown-->
            <div class="create_form mt-4 mb-4">
                <div class="form-group stu_select_list row mb-0">
                    {{ Form::label('class_name', trans('validation.attributes.backend.access.activities.class_name'), ['class' => 'col-md-2 from-control-label required']) }}
                        <div class="col-md-10">
                            <select class="form-control font-14" id="class-dd" name="class_id">
                                <option value="select">Choose Standard</option>
                                @foreach($schoolclassdata as $classdata)
                                <option value="{{$classdata->id}}">{{$classdata->class_name}} </option>
                                @endforeach
                            </select>   
                        </div>
                </div>
            </div> 

            <div class="create_form mt-4 mb-4">
                <div class="form-group stu_select_list row mb-0">
                    {{ Form::label('group_students', trans('validation.attributes.backend.access.activities.group_students'), ['class' => 'col-md-2 from-control-label required']) }}
                        <div class="col-md-10">
                            <select class="form-control font-14" id="stu-dd"   multiple="multiple" tabindex="-1" name="group_students[]">
                               
                            </select>
                        </div>
                </div>
            </div> 


            <div class="form-group row mb-0">
                <label for="status" class="col-md-2 from-control-label required">Status</label>
                
                 <div class="col-md-10">
                    <div class="checkbox d-flex align-items-center">
                        <label class="switch switch-label switch-pill switch-primary mr-2" for="role-1"><input class="switch-input" type="checkbox" name="status" id="role-1" value="1" 
                        {{ (!isset($activitiesgroup->status) ||(isset($activitiesgroup->status) && $activitiesgroup->status === 1)) ? "checked" : "" }}><span class="switch-slider" data-checked="on" data-unchecked="off"></span></label>
                    </div>
                </div><!--col-->
            </div><!--form-group-->
    </div><!--row-->
</div><!--card-body-->        
<div class="card-footer teacher_card_footer">
    <div class="row">
        <div class="col">
            <a href="{{url('teacher/myactivities/myactivities')}}" class="btn btn-danger btn-sm">Cancel</a>
        </div><!--col-->

        <div class="col text-right">
            <input class="btn btn-success btn-sm pull-right" type="submit" value="Create">
        </div><!--row-->
    </div><!--row-->
</div><!--card-footer-->  
  </div><!--card-->
    </form>
  </div>

 </div>  
 </div>   			
</section>
</div>
</div>

@endsection

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#class-dd').on('change', function () {
                var idClass = this.value;
                $("#stu-dd").html('');
                $.ajax({
                    url: "{{route('frontend.user.teacher.myactivities.fetch-student')}}",
                    type: "POST",
                    data: {
                        class_id: idClass,
                        _token: '{{csrf_token()}}'
                    },
                    dataType: 'json',
                    success: function (result) {
                        $('#stu-dd').html('<option value="">Select Student</option>');
                        $.each(result.students, function (key, value) {
                            $("#stu-dd").append('<option value="' + value
                                .id + '">' + value.first_name + '</option>');
                        });
                    }
                });
            });
        });

    </script>