<div class="navbar-custom">
    <ul class="list-unstyled topbar-right-menu float-right mb-0">
      <li class="dropdown notification-list"> <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false"> <i class="uil-envelope noti-icon font-24"></i> <span class="noti-icon-badge">4</span> </a></li>
      
      <li class="dropdown notification-list"> <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false"> <i class="dripicons-bell noti-icon"></i> 
      
  
      @if(auth()->user()->unreadNotifications->count())
        <span class="noti-icon-badge">{{auth()->user()->unreadNotifications->count()}}</span></a>
      @endif   
      
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-lg">
          <div class="dropdown-item noti-title">
            <h5 class="m-0"> <span class="float-right"> 
              <!-- <a href="javascript: void(0);" class="text-dark"> <small>Clear All</small> </a>  -->
            </span>Notification </h5>
          </div>
          
          <div style="max-height: 230px;" data-simplebar> <span class="dropdown-item notify-item">
                        
          @foreach(auth()->user()->unreadNotifications as $notification) 
            <div class="notify-icon text-danger"><i class="dripicons-bell noti-icon" style="margin-top:-20px;"></i></div>
                        
            @if($notification->data['user_role_id']=='2')
            <a href="{{route('users.show',[$notification->data['id'],'read='.$notification->id])}}">
              <p class="text-danger notify-details mb-0">New User Registered</p>
              <p class="text-mute mb-0 ml-4 user-msg"> <small>{{$notification->data['full_name']}} (Client)</small> </p>
            </a>

            @elseif($notification->data['user_role_id']=='3')
            <a href="{{route('users.show',[$notification->data['id'],'read='.$notification->id])}}">  
              <p class="text-danger notify-details mb-0">New User Registered</p>
              <p class="text-mute mb-0 ml-4 user-msg"><span><small>{{$notification->data['full_name']}} (Site Manager)</small></p>
            </a>

            @elseif($notification->data['user_role_id']=='5')
            <a href="{{route('users.show',[$notification->data['id'],'read='.$notification->id])}}">
              <p class="text-danger notify-details mb-0">New User Registered</p>
              <p class="text-mute mb-0  ml-4 user-msg"><small>{{$notification->data['full_name']}} (Cleaning Manager)</small></p>
            </a>

            @elseif($notification->data['user_role_id']=='6')
            <a href="{{route('users.show',[$notification->data['id'],'read='.$notification->id])}}">
              <p class="text-danger notify-details mb-0">New User Registered</p>
              <p class="text-mute mb-0 ml-4 user-msg"> <small>{{$notification->data['full_name']}} (Cleaner)</small> </p>
            </a>

            @else
            <a href="{{route('tickets.details',[$notification->data['id'], 'read='.$notification->id])}}">
              <p class="text-danger notify-details mb-0">New Ticket Generated</p>
              <p class="text-mute mb-0 ml-4"><small>{{$notification->data['task']}}</small></p>
            </a>    
            @endif

</span> <span class="dropdown-item notify-item">
            
            @endforeach        
          
            @foreach(auth()->user()->readNotifications as $notification)
           
          @endforeach         
                  
          <a href="{{route('markRead')}}" class="dropdown-item text-center text-primary notify-item notify-all font-weight-bold">Clear All </a> 
          </div>
         
      </li>
      <li class="dropdown notification-list"> 
        <a class="nav-link dropdown-toggle nav-user arrow-none mr-0" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false"> 
          <span class="account-user-avatar mr-2"> 
            @if(!empty(Auth::user()->avtar) && File::exists(USER_IMAGE_ROOT_PATH . Auth::user()->avtar))
              <img src="{{ USER_IMAGE_URL . Auth::user()->avtar}}" alt="user-image" class="img-thumbnail" style="width: 50px; height: 45px;"> 
            @else
              <img src="{{NO_USER_IMAGE}}" alt="user-image" class="rounded-circle"> 
            @endif
          </span>
          
          <?php $role = Auth::user()->user_role_id; ?>
          @if($role==1)
            <span class="account-user-name ml-2 mt-1">{{Auth::user()->full_name}}</span> <span class="account-position ml-2">Super Admin</span>
          @elseif($role==2)
            <span class="account-user-name ml-2 mt-1">{{Auth::user()->full_name}}</span> <span class="account-position ml-2">Client</span>
          @elseif($role==3)
            <span class="account-user-name ml-2 mt-1">{{Auth::user()->full_name}}</span> <span class="account-position ml-2">Site Manager</span>
          @elseif($role==4)
            <span class="account-user-name ml-2 mt-1">{{Auth::user()->full_name}}</span> <span class="account-position ml-2">Clining Company</span>      
          @elseif($role==5)
            <span class="account-user-name ml-2 mt-1">{{Auth::user()->full_name}}</span> <span class="account-position ml-2">Cleaning Manager</span>      
          @elseif($role==6)
            <span class="account-user-name ml-2 mt-1">{{Auth::user()->full_name}}</span> <span class="account-position ml-2">Cleaner</span>      
          @endif
            

</span>
        <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu profile-dropdown"> 
          <a href="{{route('users.profile', Auth::user()->id)}}" class="dropdown-item notify-item"> <i class="mdi mdi-account-circle mr-1"></i> <span>My Account</span> </a> 
          <a href="javascript:void(0);" class="dropdown-item notify-item"> <i class="mdi mdi-account-edit mr-1"></i> <span>Settings</span> </a> 
          <a href="javascript:void(0);" class="dropdown-item notify-item"> <i class="mdi mdi-lifebuoy mr-1"></i> <span>Support</span> </a> 
          <a href="{{route('logout')}}" class="dropdown-item notify-item"> <i class="mdi mdi-logout mr-1"></i> <span>Logout</span> </a> 
        </div>
      </li>
    </ul>
    <button class="button-menu-mobile open-left disable-btn"> <i class="mdi mdi-menu"></i> </button>
</div>